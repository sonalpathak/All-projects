﻿using UIKit;

namespace CancellableTasks
{
	public class Application
	{
		// This is the main entry point of the application.
		static void Main (string[] args)
		{
			UIApplication.Main (args, null, typeof(AppDelegate));
		}
	}
}
