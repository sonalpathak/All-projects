﻿using System;
using System.Threading;
using Foundation;
using UIKit;

namespace CancellableTasks
{
	public class AppDelegate : UIApplicationDelegate
	{
		public override UIWindow Window
		{
			get;
			set;
		}
	}
}

