function create_tables(){
	var db=window.openDatabase("superstore","1.0","superstore",1000000000000);
	db.transaction(function(tx){
       //  tx.executeSql("drop table if exists order_table");
       //  tx.executeSql("drop table if exists order_details");

       // tx.executeSql("drop table if exists cart");
    
      // tx.executeSql("drop table if exists sales");
    
       
     //    tx.executeSql("drop table if exists customer_details");
     
     //    tx.executeSql("drop table if exists cart");
       
        



        tx.executeSql("drop table if exists product_batch");
        
      
     
      tx.executeSql("drop table if exists product");
		  // tx.executeSql("drop table if exists user");
       //tx.executeSql("drop table if exists dealer");
           //   tx.executeSql("drop table if exists units");
    //     tx.executeSql("drop table if exists product_tax");
      
		 tx.executeSql("create table if not exists user("+"user_id integer primary key autoincrement,"
           + "username integer,"
           + "password integer,"
           + "number   integer,"
           + "admin integer,"
           + "dataentry integer,"
           + "billing integer"
        +")",null,success_user,logger_user);
		     function success_user(tx){
      console.log("user table created");
    }
    function logger_user(tx,error){
      console.log("Error", error.message);
  }
tx.executeSql("create table if not exists dealer("+"dealer_id integer primary key autoincrement,"
           + "dealername integer,"
          
           + "number   integer"
        +")",null,success_dealer,logger_user);
         function success_dealer(tx){
      console.log("dealer table created");
    }
    function logger_user(tx,error){
      console.log("Error", error.message);
  }
  // tx.executeSql("create table if not exists roles("+"role_id integer primary key autoincrement,"
  //   +"role_name text"
  //    +")",null,success_roles,logger_roles);
  // function success_roles(tx){
  //   console.log("roles table created");
  // }
  // function logger_roles(tx,error){
  //   console.log("Error creating the roles table",error.message);
  // }
  tx.executeSql("create table if not exists category("+"category_id integer primary key autoincrement,"
    +"category_name text"
     +")",null,success_category,logger_category);
  function success_category(tx){
    console.log("category table created");
  }
  function logger_category(tx,error){
    console.log("Error creating the roles table",error.message);
  }
  // tx.executeSql("create table if not exists product("+ "category_id integer,"
  //   + "product_id integer primary key autoincrement,"
  //   + "product_name text"
    
 
  //   +")",null,success_product,logger_product);
  // function success_product(tx){
  //   console.log(" product table created");
  // }
  // function logger_product(tx,error){
  //   console.log("error creating product table",error.message);
  // }
  tx.executeSql("create table if not exists product_tax("+"category_id integer,"
    + "product_id integer primary key autoincrement,"
    + "product_name text,"
  
    + "tax integer,"
    + "commission integer"
    +")",null,success_product_tax,logger_product_tax);
  function success_product_tax(tx){
    console.log("product_tax table created ");
  }
  function logger_product_tax(tx,error){
    console.log(error.message);
  }
  
  // tx.executeSql("create table if not exists product_batch("+"batch_id integer primary key autoincrement,"
  
  //   + "category_id integer,"
  //   + "product_id integer,"
  //   + "product_name text,"
  //   + "product_variant text,"
  //   + "batch_number integer(1000),"
  //   + "quantity integer,"
  //   + "dealername text,"
  //   + "price integer,"
  //   + "selling_price integer,"
  //   + "Expiry_date date,"
  //   + "Active text"
  //   +")",null,success_product_batch,logger_product_batch);

  // function success_product_batch(tx){
  //   console.log("product_batch table created");
  // }
  // function logger_product_batch(tx,error){
  //   console.log("error creating table",error.message);
  // }
  tx.executeSql("create table if not exists units("+"unit_id integer primary key autoincrement,"
    + "unit_name text"
    +")",[],success_units,logger_units);
  function success_units(tx){
    console.log("units table created");
  }
  function logger_units(tx,error){
    console.log("error creating table",error.message);
  }
   tx.executeSql("create table if not exists customer_details("+"customer_id integer primary key autoincrement,"
    + "customer_name text,"
    + "number integer"
    +")",[],success_customer_details,logger_customer_details);
  function success_customer_details(tx){
    console.log("customer_details table created");
  }
  function logger_customer_details(tx,error){
    console.log("error creating table",error.message);
  }

//   tx.executeSql('select * from units',[],function(tx,results){
//   if(results.rows.length==0){

//   tx.executeSql("insert into units(unit_name) values('grams')",[]);
//    tx.executeSql("insert into units(unit_name) values('kgs')",[]);
//    tx.executeSql("insert into units(unit_name) values('lts')",[]);
//    tx.executeSql("insert into units(unit_name) values('mlts')",[]);
//   function success_units_insert(tx){
//     console.log("inserted into units table");
//   }
//   function logger_units_insert(tx,error){
//     console.log("error entering into units table",error.message);
//   }
// }
// });
  tx.executeSql("create table if not exists addproduct("+"batch_id integer primary key  AUTOINCREMENT ,"
    
    + "category_id integer,"
    + "product_id integer,"
    + "product_name text,"
    + "batch_number text,"
    + "dealername text,"
    + "quantity integer,"
    + "quantity_sold integer,"
    + "product_variant integer,"
    + "units text,"
    + "price integer,"
    + "created date,"
    + "Expiry_date date,"
    + "Active text"
   +")",null,success_addproduct,logger_addproduct);
  function success_addproduct(tx)
  {
    console.log("addproduct table created");
  }
  function logger_addproduct(tx,error)
  {
    console.log("error creating addproduct table",error.message);
  }

  tx.executeSql("create table if not exists cart("+"cart_id integer primary key autoincrement ,"
    

    + "batch_id integer,"
    + "product_id integer,"
    + "product_name text,"
    + "weight integer,"
    + "variant text,"
    + "unit_price integer,"
    + "quantity integer,"
    + "selling_price integer,"
    + "tax integer,"
    + "total integer,"

   
    + "selling_date date"
    +")",null,success_cart,logger_cart);
  function success_cart(tx){
    console.log("cart table created");
  }
  function logger_cart(tx,error){
    console.log("error creating cart table",error.message);
  }

  // tx.executeSql("create table")


  tx.executeSql("create table if not exists order_table("+"order_id integer primary key autoincrement,"
    +"order_details_id integer,"
  
+"batch_id integer,"
+"product_id integer,"
+"product_name text,"
+"weight integer,"
+"variant text,"
+"unit_price integer,"
+"quantity integer,"
+"selling_price integer,"
+"tax integer,"
+"selling_date date,"
+"total integer"

    +")",null,success_order,logger_order);
   function success_order(tx){
    console.log("order table created");
  }
  function logger_order(tx,error){
    console.log("error creating cart table",error.message);
  }
tx.executeSql("create table if not exists order_details("+"order_details_id integer primary key autoincrement,"
// +"order_id integer,"
// +"product_id integer,"



+"quantity integer,"

+"total integer,"
+"sold_date date"


    +")",null,success_order_details,logger_order_details);
function success_order_details(tx){
  console.log("created order_details");
}
function logger_order_details(tx,error){
  console.log("error creating order_details",error.message);
}
tx.executeSql("create table if not exists sales("+"sales_id integer primary key autoincrement,"
  +"product_id integer,"
  +"product_name text,"
  +"quantity_sold integer,"
   +"sold_date date"
  
  // +"FOREIGN KEY(product_id) REFERENCES product_tax(product_id)"



 + ")",null,success_sales,logger_sales);
function success_sales(tx){
  console.log("created order_details");
}
function logger_sales(tx,error){
  console.log("error creating order_details",error.message);
}
tx.executeSql("create table if not exists total_stock("+"stock_id integer primary key autoincrement,"
  // +"sales_id integer,"
  +"product_id integer,"
  +"product_name text,"
  +"quantity integer,"
  +"sold_date date"
  // +"FOREIGN KEY(product_id) REFERENCES product_tax(product_id)"



 + ")",null,success_sales,logger_sales);
function success_sales(tx){
  console.log("created order_details");
}
function logger_sales(tx,error){
  console.log("error creating order_details",error.message);
}

	});//transactions
}//create_tables