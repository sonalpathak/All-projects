function create_tables(){
	var db=window.openDatabase("superstore","1.0","superstore",1000000000);
	db.transaction(function(tx){
       tx.executeSql("drop table if exists product_batch");
     // tx.executeSql("drop table if exists weight");
     //   tx.executeSql("drop table if exists product_tax");
     //  tx.executeSql("drop table if exists product");
		  // tx.executeSql("drop table if exists user");
       //tx.executeSql("drop table if exists dealer");
      
		 tx.executeSql("create table if not exists user("+"user_id integer primary key autoincrement,"
           + "username integer,"
           + "password integer,"
           + "number   integer,"
           + "admin integer,"
           + "dataentry integer,"
           + "billing integer"
        +")",null,success_user,logger_user);
		     function success_user(tx){
      console.log("user table created");
    }
    function logger_user(tx,error){
      console.log("Error", error.message);
  }
tx.executeSql("create table if not exists dealer("+"dealer_id integer primary key autoincrement,"
           + "dealername integer,"
          
           + "number   integer"
        +")",null,success_dealer,logger_user);
         function success_dealer(tx){
      console.log("dealer table created");
    }
    function logger_user(tx,error){
      console.log("Error", error.message);
  }
  tx.executeSql("create table if not exists roles("+"role_id integer primary key autoincrement,"
    +"role_name text"
     +")",null,success_roles,logger_roles);
  function success_roles(tx){
    console.log("roles table created");
  }
  function logger_roles(tx,error){
    console.log("Error creating the roles table",error.message);
  }
  tx.executeSql("create table if not exists category("+"category_id integer primary key autoincrement,"
    +"category_name text"
     +")",null,success_category,logger_category);
  function success_category(tx){
    console.log("category table created");
  }
  function logger_category(tx,error){
    console.log("Error creating the roles table",error.message);
  }
  tx.executeSql("create table if not exists product("+ "category_id integer,"
    + "product_id integer primary key autoincrement,"
    + "product_name text"
    
 
    +")",null,success_product,logger_product);
  function success_product(tx){
    console.log(" product table created");
  }
  function logger_product(tx,error){
    console.log("error creating product table",error.message);
  }
  tx.executeSql("create table if not exists product_tax("+"category_id integer,"
    + "product_id integer,"
    + "product_name text,"
    + "weight text,"
    + "tax integer,"
    + "commission integer"
    +")",null,success_product_tax,logger_product_tax);
  function success_product_tax(tx){
    console.log("product_tax table created ");
  }
  function logger_product_tax(tx,error){
    console.log(error.message);
  }
  tx.executeSql("create table if not exists weight("+"weight_id integer primary key autoincrement,"
    + "product_id integer,"
    + "product_variant text"
    +")",null,success_weight,logger_weight);
    function success_weight(tx){
    console.log("weight table created ");
  }
  function logger_weight(tx,error){
    console.log(error.message);
  }
  // tx.executeSql("create table if not exists product_batch("+"batch_id integer primary key autoincrement,"
  //   + "category_id integer,"
  //   + "product_id integer,"
  //   + "product_name text,"
  //   + "product_variant text,"
  //   + "batch_number integer(1000),"
  //   + "quantity integer,"
  //   + "dealername text,"
  //   + "price integer,"
  //   + "Expiry_date date"
  //   +")",null,success_product_batch,logger_product_batch);

  // function success_product_batch(tx){
  //   console.log("product_batch table created");
  // }
  // function logger_product_batch(tx,error){
  //   console.log("error creating table",error.message);
  // }


	});
}