# Introduction to Quick UI Doc

This folder holds the projects that are being used as a part of the Quick UI intro doc that is being worked on.


* **HelloQuickUIWorld** - A simple HelloWorld project. Will be published with the doc.
* **MyQuickUIApplication** - Will not be published - using this for screenshots and such.
* **QuickUISample** - A sample project that shows how to make pages, use nagivation, and databinding. This project does not use MVVM.

Other projects of interest:

* **../QuickUIDemo** - Made by the DE team.
* **../QuickUIIntroApp** - Made by the QuickUI team. 
