﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloXamarinFormsWorldXaml
{
    public partial class StackLayoutExample1
    {
        public StackLayoutExample1()
        {
            InitializeComponent();
        }
    }
}
