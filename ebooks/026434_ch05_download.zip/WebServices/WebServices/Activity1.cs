﻿using System;
using System.Collections.Generic;
using System.Net;
using System.IO;
using System.ServiceModel;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Net;
namespace WebServices
{
    [Activity(Label = "Remote Data", MainLauncher = true)]
    public class Activity1 : Activity
    {
        private TextView tv;
        private string gResult = "Result: ";
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.main);
            
            // Get our button from the layout resource,
            // and attach an event to it
            Button btnCallAsyncREST = FindViewById<Button>(Resource.Id.callasyncrest);
            btnCallAsyncREST.Click += new EventHandler(btnCallAsyncREST_Click);
            Button btnCallSyncREST = FindViewById<Button>(Resource.Id.callsyncrest);
            btnCallSyncREST.Click += new EventHandler(btnCallSyncREST_Click);
            Button btnCallAsyncWSDL = FindViewById<Button>(Resource.Id.callwsdlasync);
            btnCallAsyncWSDL.Click += new EventHandler(btnCallAsyncWSDL_Click);
            Button btnCallWSDL = FindViewById<Button>(Resource.Id.callwsdl);
            btnCallWSDL.Click += new EventHandler(btnCallWSDL_Click);
            Button btnCallWSDLClient = FindViewById<Button>(Resource.Id.callwsdlclient);
            btnCallWSDLClient.Click += new EventHandler(btnCallWSDLClient_Click);
            Button btnCallASMX = FindViewById<Button>(Resource.Id.callasmx);
            btnCallASMX.Click += new EventHandler(btnCallASMX_Click);
            Button btnRESTJSON = FindViewById<Button>(Resource.Id.callrestjson);
            btnRESTJSON.Click += new EventHandler(btnRESTJSON_Click);
            Button btnRESTJSONLINQ = FindViewById<Button>(Resource.Id.callrestjsonlinq);
            btnRESTJSONLINQ.Click += new EventHandler(btnRESTJSONLINQ_Click);
            Button btnRESTXML = FindViewById<Button>(Resource.Id.callrestxml);
            btnRESTXML.Click += new EventHandler(btnRESTXML_Click);
            tv = FindViewById<TextView>(Resource.Id.textout);
            tv.Text = "Starting";
        }

        void btnRESTXML_Click(object sender, EventArgs e)
        {
            string Url = "http://api.twitter.com/1/statuses/user_timeline.xml?screen_name=wbm";
            try
            {
                // Create the web request
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                // Set type to POST
                request.Method = "GET";
                request.ContentType = "application/xml";
                request.BeginGetResponse(new AsyncCallback(ProcessRestXmlLINQHttpResponse), request);
            }
            catch (WebException we)
            {
                tv.Text = we.Message;
                Android.Util.Log.Error("http request", "Exception: " + we.Message);
                //System.Diagnostics.Debug.WriteLine("Exception: " + we.Message);
            }
            catch (System.Exception sysExc)
            {
                tv.Text = sysExc.Message;
                Android.Util.Log.Error("http request", "Exception: " + sysExc.Message);
            }
        }

        void ProcessRestXmlLINQHttpResponse(IAsyncResult iar)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)iar.AsyncState;
                HttpWebResponse response;
                response = (HttpWebResponse)request.EndGetResponse(iar);
                System.IO.StreamReader strm = new System.IO.StreamReader(
                    response.GetResponseStream());
                //string responseString = strm.ReadToEnd();
                System.Xml.Linq.XDocument xd = XDocument.Load(strm);
                var twt = (from x in xd.Root.Descendants("status") 
                            where x != null
                            select new Tweet
                            {
                                StatusId = x.Element("id").Value,
                                UserName = x.Element("user").Element("screen_name").Value,
                                ProfileImage = x.Element("user").Element("profile_image_url").Value,
                                Status = x.Element("text").Value,
                                StatusDate = x.Element("created_at").Value
                            }).ToList<Tweet>();

                this.RunOnUiThread(() => tv.Text = "records: " + twt.Count.ToString());
                Android.Util.Log.Debug("http response", "finished");
            }
            catch (System.Exception sysExc)
            {
                Android.Util.Log.Error("http response", "Exception: " + sysExc.Message);
                this.RunOnUiThread(() => tv.Text = "Exception: " + sysExc.Message);
            }
        }

        void btnRESTJSONLINQ_Click(object sender, EventArgs e)
        {
            string Url = "http://www.twtmstr.com/webservices/remoteapi.svc/GetUserTimeLine";
            System.Json.JsonObject ld = new System.Json.JsonObject() 
                { { "UserName", "MonoDroidBookEx" },
                    { "PassWord", "MonoDroidIsGreat" },
                    { "AppKey", "blah" } };
            System.Json.JsonObject bd = new System.Json.JsonObject()
                { { "ld", ld },
                    { "TwitterId", "monodroidbookex"},
                    { "PageIndex", 1 }};
            string Body = bd.ToString();
            byte[] byteData = System.Text.UTF8Encoding.UTF8.GetBytes(Body);
            try
            {
                // Create the web request
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                request.ContentLength = Body.Length;

                // Set type to POST
                request.Method = "POST";
                request.ContentType = "application/json";


                // Write the parameters
                StreamWriter stOut = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                stOut.Write(Body);
                stOut.Close();

                request.BeginGetResponse(new AsyncCallback(ProcessRestJSONLINQHttpResponse), request);
            }
            catch (WebException we)
            {
                tv.Text = we.Message;
                Android.Util.Log.Error("http request", "Exception: " + we.Message);
                //System.Diagnostics.Debug.WriteLine("Exception: " + we.Message);
            }
            catch (System.Exception sysExc)
            {
                tv.Text = sysExc.Message;
                Android.Util.Log.Error("http request", "Exception: " + sysExc.Message);
            }
        }

        void ProcessRestJSONLINQHttpResponse(IAsyncResult iar)
        {
            try
            {
                Int64 t1 = DateTime.Now.Ticks;
                Int64 t2;
                Int64 TotalTicks;
                HttpWebRequest request = (HttpWebRequest)iar.AsyncState;
                HttpWebResponse response;
                response = (HttpWebResponse)request.EndGetResponse(iar);
                System.IO.StreamReader strm = new System.IO.StreamReader(
                    response.GetResponseStream());
                System.Json.JsonArray jsonArray = (System.Json.JsonArray)System.Json.JsonArray.Load(strm);
                //List<Tweet> twt = new List<Tweet>();
                var twt = (from jsonTweet in jsonArray
                           select new Tweet
                           {
                               ProfileImage = jsonTweet["ProfileImage"].ToString(),
                               Status = jsonTweet["Status"].ToString(),
                               StatusDate = jsonTweet["StatusDate"],
                               StatusId = jsonTweet["StatusId"].ToString(),
                               UserName = jsonTweet["UserName"].ToString()
                           }).ToList<Tweet>();
                t2 = DateTime.Now.Ticks;
                TotalTicks = t2 - t1;
                this.RunOnUiThread(() => tv.Text = "Ticks with LINQ: " + TotalTicks.ToString());
                Android.Util.Log.Debug("http response", "finished");
            }
            catch (System.Exception sysExc)
            {
                Android.Util.Log.Error("http response", "Exception: " + sysExc.Message);
                this.RunOnUiThread(() => tv.Text = "Exception: " + sysExc.Message);
            }
        }

        void btnRESTJSON_Click(object sender, EventArgs e)
        {
            string Url = "http://www.twtmstr.com/webservices/remoteapi.svc/GetUserTimeLine";
            System.Json.JsonObject ld = new System.Json.JsonObject() 
                { { "UserName", "MonoDroidBookEx" },
                    { "PassWord", "MonoDroidIsGreat" },
                    { "AppKey", "blah" } };
            System.Json.JsonObject bd = new System.Json.JsonObject()
                { { "ld", ld },
                    { "TwitterId", "monodroidbookex"},
                    { "PageIndex", 1 }};
            string Body = bd.ToString(); 
            byte[] byteData = System.Text.UTF8Encoding.UTF8.GetBytes(Body);
            try
            {
                // Create the web request
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                request.ContentLength = Body.Length;

                // Set type to POST
                request.Method = "POST";
                request.ContentType = "application/json";

                // Write the parameters
                StreamWriter stOut = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                stOut.Write(Body);
                stOut.Close();

                request.BeginGetResponse(new AsyncCallback(ProcessRestJSONHttpResponse), request);
            }
            catch (WebException we)
            {
                tv.Text = we.Message;
                Android.Util.Log.Error("http request", "Exception: " + we.Message);
                //System.Diagnostics.Debug.WriteLine("Exception: " + we.Message);
            }
            catch (System.Exception sysExc)
            {
                tv.Text = sysExc.Message;
                Android.Util.Log.Error("http request", "Exception: " + sysExc.Message);
            }
        }

        void ProcessRestJSONHttpResponse(IAsyncResult iar)
        {
            try
            {
                Int64 t1 = DateTime.Now.Ticks;
                Int64 t2;
                Int64 TotalTicks;
                HttpWebRequest request = (HttpWebRequest)iar.AsyncState;
                HttpWebResponse response;
                response = (HttpWebResponse)request.EndGetResponse(iar);
                System.IO.StreamReader strm = new System.IO.StreamReader(
                    response.GetResponseStream());
                System.Json.JsonArray jsonArray = (System.Json.JsonArray)System.Json.JsonArray.Load(strm);
                List<Tweet> twt = new List<Tweet>();
                foreach (System.Json.JsonObject jsonTweet in jsonArray)
                {
                    Tweet t = new Tweet();
                    t.ProfileImage = jsonTweet["ProfileImage"].ToString();
                    t.Status = jsonTweet["Status"].ToString();
                    t.StatusDate = jsonTweet["StatusDate"];
                    t.StatusId = jsonTweet["StatusId"].ToString();
                    t.UserName = jsonTweet["UserName"].ToString();
                    twt.Add(t);
                }
                t2 = DateTime.Now.Ticks;
                TotalTicks = t2 - t1;
                this.RunOnUiThread(() => tv.Text = "Records returned: " + twt.Count.ToString());
                this.RunOnUiThread(() => tv.Text += " Ticks with Array: " + TotalTicks.ToString());
                Android.Util.Log.Debug("http response", "finished");
            }
            catch (System.Exception sysExc)
            {
                Android.Util.Log.Error("http response", "Exception: " + sysExc.Message);
                this.RunOnUiThread(() => tv.Text = "Exception: " + sysExc.Message);
            }
        }

        void btnCallASMX_Click(object sender, EventArgs e)
        {
            com.w3schools.www.TempConvert tc = new com.w3schools.www.TempConvert();
            tc.CelsiusToFahrenheitCompleted += new com.w3schools.www.CelsiusToFahrenheitCompletedEventHandler(tc_CelsiusToFahrenheitCompleted);
            tc.CelsiusToFahrenheitAsync("27");
        }

        void tc_CelsiusToFahrenheitCompleted(object sender, com.w3schools.www.CelsiusToFahrenheitCompletedEventArgs e)
        {
            this.RunOnUiThread(() => tv.Text = gResult + e.Result);
        }

        void btnCallWSDLClient_Click(object sender, EventArgs e)
        {
            try
            {
                WebServiceWSDLClient wsClient = 
                    new WebServiceWSDLClient(new BasicHttpBinding(), 
                    new EndpointAddress("http://www.twtmstr.com/webservices/webservicewsdl.svc"));
                wsClient.LoginCompleted += new EventHandler<LoginCompletedEventArgs>(wsClient_LoginCompleted);
                wsClient.LoginAsync("MonoDroidBookEx", "MonoDroidIsGreat", "blah");
            }
            catch (System.Exception sysExc)
            {
                tv.Text = "Exception: " + sysExc.Message;
            }
        }

        void wsClient_LoginCompleted(object sender, LoginCompletedEventArgs e)
        {
            this.RunOnUiThread(() => tv.Text = gResult + e.Result.ToString());
        }

        void btnCallWSDL_Click(object sender, EventArgs e)
        {
            com.parasoft.soatest.Calculator calc = new com.parasoft.soatest.Calculator();
            var result = calc.add(2.0f, 3.0f);
            tv.Text = gResult + result.ToString();
        }

        void btnCallAsyncWSDL_Click(object sender, EventArgs e)
        {
            com.parasoft.soatest.Calculator calc = new com.parasoft.soatest.Calculator();
            calc.addCompleted += new com.parasoft.soatest.addCompletedEventHandler(calc_addCompleted);
            calc.addAsync(2.0f, 3.0f);
        }

        void calc_addCompleted(object sender, com.parasoft.soatest.addCompletedEventArgs e)
        {
            RunOnUiThread(delegate
            {
                tv.Text = String.Format("result:{0}", e.Result);
            });
        }

        //void ws_LoginCompleted(object sender, com.twtmstr.www.LoginCompletedEventArgs e)
        //{
        //    string output = String.Empty;
        //    if (e.LoginResult == true)
        //    {
        //        output = "Successful login.";
        //    }
        //    else
        //    {
        //        output = "Unsuccessful login.";
        //    }
        //    this.RunOnUiThread(() => tv.Text = output);
        //}

        void btnCallSyncREST_Click(object sender, EventArgs e)
        {
            string Url = "http://www.twtmstr.com/webservices/remoteapi.svc/login";
            System.Json.JsonObject ld = new System.Json.JsonObject() 
                { { "UserName", "MonoDroidBookEx" },
                    { "PassWord", "MonoDroidIsGreat" },
                    { "AppKey", "blah" } };
            System.Json.JsonObject bd = new System.Json.JsonObject() { { "ld", ld } };
            string Body = bd.ToString(); 
            byte[] byteData = System.Text.UTF8Encoding.UTF8.GetBytes(Body);
            try
            {
                // Create the web request
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                request.ContentLength = Body.Length;

                // Set type to POST
                request.Method = "POST";
                request.ContentType = "application/json";

                // Write the parameters
                StreamWriter stOut = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                stOut.Write(Body);
                stOut.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                //Console.WriteLine("get response.");
                System.IO.StreamReader strm = new System.IO.StreamReader(
                    response.GetResponseStream());
                string responseString = strm.ReadToEnd();
                response.Close();
                tv.Text = responseString;

                Android.Util.Log.Debug("sync http response", responseString);
            }
            catch (WebException we)
            {
                tv.Text = we.Message;
                Android.Util.Log.Error("sync http request", "Exception: " + we.Message);
                //System.Diagnostics.Debug.WriteLine("Exception: " + we.Message);
            }
            catch (System.Exception sysExc)
            {
                tv.Text = sysExc.Message;
                Android.Util.Log.Error("sync http request", "Exception: " + sysExc.Message);
            }
        }

        void btnCallAsyncREST_Click(object sender, EventArgs e)
        {
            string Url = "http://www.twtmstr.com/webservices/remoteapi.svc/login";
            System.Json.JsonObject ld = new System.Json.JsonObject() 
                { { "UserName", "MonoDroidBookEx" },
                    { "PassWord", "MonoDroidIsGreat" },
                    { "AppKey", "blah" } };
            System.Json.JsonObject bd = 
                new System.Json.JsonObject() { { "ld", ld } };
            string Body = bd.ToString();
            byte[] byteData = System.Text.UTF8Encoding.UTF8.GetBytes(Body);
            try
            {
                // Create the web request
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                request.ContentLength = Body.Length;

                // Set type to POST
                request.Method = "POST";
                request.ContentType = "application/json";

                // Write the parameters
                StreamWriter stOut = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                stOut.Write(Body);
                stOut.Close();

                request.BeginGetResponse(new AsyncCallback(ProcessRestHttpResponse), request);
            }
            catch (WebException we)
            {
                tv.Text = we.Message;
                Android.Util.Log.Error("http request", "Exception: " + we.Message);
                //System.Diagnostics.Debug.WriteLine("Exception: " + we.Message);
            }
            catch (System.Exception sysExc)
            {
                tv.Text = sysExc.Message;
                Android.Util.Log.Error("http request", "Exception: " + sysExc.Message);
            }
        }

        private void ProcessRestHttpResponse(IAsyncResult iar)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)iar.AsyncState;
                HttpWebResponse response;
                response = (HttpWebResponse)request.EndGetResponse(iar);

                //Console.WriteLine("get response.");
                System.IO.StreamReader strm = new System.IO.StreamReader(
                    response.GetResponseStream());
                string responseString = strm.ReadToEnd();
                response.Close();
                this.RunOnUiThread(() => tv.Text = responseString);

                Android.Util.Log.Debug("http response", responseString);
            }
            catch (System.Exception sysExc)
            {
                Android.Util.Log.Error("http response", "Exception: " + sysExc.Message);
                this.RunOnUiThread(() => tv.Text = "Exception: " + sysExc.Message);
            }
        }
    }
}

