﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Locations;

namespace ProximityAlerts
{
    [Activity(Label = "Proximity Alerts", MainLauncher = true)]
    public class Activity1 : Activity
    {
        private static String MYPROXIMITY = "com.monodroid.alert";

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);
            Button button = FindViewById<Button>(Resource.Id.MyButton);
            button.Click += delegate { SetProximityAlert(); };
        }

        private void SetProximityAlert() {

            String locService = Context.LocationService;
            LocationManager locationManager;
            locationManager = (LocationManager)GetSystemService(locService);
            //Lat/Lon for my office.
            double lat = 35.89988475;
            double lng = -84.12312175;
            //I want to see this fairly quickly, so I am 
            // wanting to see a change at the 
            float radius = .1f; // meters.  
            long expiration = -1; // do not expire

            Intent intent = new Intent(this, typeof(ReceiveProximityMessages));
            PendingIntent proximityIntent = PendingIntent.GetBroadcast(this, -1,
                intent, 0);
            locationManager.AddProximityAlert(lat, lng, radius, expiration, proximityIntent);
            IntentFilter filter = new IntentFilter(MYPROXIMITY);
            RegisterReceiver(new ReceiveProximityMessages(), filter);
        }
    }
}

