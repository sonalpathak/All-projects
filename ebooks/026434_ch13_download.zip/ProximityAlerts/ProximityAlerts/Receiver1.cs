using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Locations;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace ProximityAlerts
{
    [BroadcastReceiver(Name = "com.monodroid.alert")]
    public class ReceiveProximityMessages : BroadcastReceiver
    {
        
        public override void OnReceive(Context context, Intent intent)
        {
            String locService = Context.LocationService;
            LocationManager locationManager;
            locationManager = (LocationManager)context.GetSystemService(locService);
            String key = LocationManager.KeyProximityEntering;
            Boolean entering = intent.GetBooleanExtra(key, false);
            ShowToast(context, entering);
        }
        void ShowToast(Context context, bool entering)
        {
            var text = "Entering: " + entering.ToString();
            Toast.MakeText(context, text, ToastLength.Short).Show();
        }
    }
}