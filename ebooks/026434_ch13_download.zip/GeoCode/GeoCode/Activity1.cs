﻿using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Locations;

namespace GeoCode
{
    [Activity(Label = "GeoCode", MainLauncher = true)]
    public class Activity1 : Activity
    {
        int count = 1;
        EditText et;
        TextView tvLat, tvLon;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            // Get our button from the layout resource,
            // and attach an event to it
            et = FindViewById<EditText>(Resource.Id.Address);
            tvLat = FindViewById<TextView>(Resource.Id.Lat);
            tvLon = FindViewById<TextView>(Resource.Id.Lon);
            Button button = FindViewById<Button>(Resource.Id.MyButton);

            button.Click += delegate {
                try
                {
                    //There is a bug in the emulator that results in an error.
                    //This code works properly on a device.
                    var add = Convert.ToString(et.Text);
                    Geocoder geocoder = new Geocoder(this, Java.Util.Locale.Default);
                    IList<Android.Locations.Address> result = geocoder.GetFromLocationName(add, 10);
                    if (result != null)
                    {
                        tvLat.Text = "Latitude: " + result[0].Latitude.ToString();
                        tvLon.Text = "Longitude: " + result[0].Longitude.ToString();
                    }
                }
                catch (System.Exception sysExc)
                {
                    Toast.MakeText(this, sysExc.Message, ToastLength.Short).Show();
                }

            };
        }
    }
}

