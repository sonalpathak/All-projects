using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.GoogleMaps;

namespace MapOverlayExample
{
	[Activity (Label = "MapOverlayExample", MainLauncher = true)]
	public class Activity1 : MapActivity
	{
		MapView mapView;
		MyLocationOverlay myLocationOverlay;
		
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);
			
			mapView = FindViewById<MapView>(Resource.Id.mapView);
			mapView.Controller.SetZoom(19);
			
			myLocationOverlay = new MyLocationOverlay (this, mapView);
			myLocationOverlay.RunOnFirstFix (() => {
				mapView.Controller.AnimateTo (myLocationOverlay.MyLocation);
			});
			mapView.Overlays.Add (myLocationOverlay);
		}
		
		protected override void OnResume ()
		{
			base.OnResume ();
			
			myLocationOverlay.EnableMyLocation();
		}
		
		protected override void OnStop ()
		{
			base.OnStop ();
			
			myLocationOverlay.DisableMyLocation();
		}
		
		#region implemented abstract members of Android.GoogleMaps.MapActivity
		protected override bool IsRouteDisplayed {
			get {
				return false;
			}
		}
		#endregion
	}
}


