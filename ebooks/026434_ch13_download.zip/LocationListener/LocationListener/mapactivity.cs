using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Locations;

namespace LocationListener
{
    [Activity(Label = "Map Activity")]
    public class mapactivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Id.map_view);
            //Android.Runtime.JNIEnv.GetObjectClass;
            //MapView mapView = FindViewById<MapView>(Resource.id.map_view);
            // Create your application here
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
        }
    }
}