using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Locations;

namespace LocationListener
{
    public class LocListener : Java.Lang.Object, Android.Locations.ILocationListener
    {
        private Activity1 _caller;
        public LocListener(Activity1 caller)
        {
            _caller = caller;
        }
        public void OnLocationChanged(Android.Locations.Location location)
        {
            double lat = location.Latitude;
            double lon = location.Longitude;
            //_caller.Lat = lat;
            //_caller.Lon = lon;

            //throw new NotImplementedException();
        }

        public void OnProviderDisabled(string provider)
        {
            //throw new NotImplementedException();
        }

        public void OnProviderEnabled(string provider)
        {
            //throw new NotImplementedException();
        }

        public void OnStatusChanged(string provider, Availability status, Bundle extras)
        {
            //throw new NotImplementedException();
        }
    }
}