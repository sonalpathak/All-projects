﻿using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Locations;

namespace LocationListener
{
    [Activity(Label = "Wally Location Test", MainLauncher = true)]
    public class Activity1 : Activity, Android.Locations.ILocationListener
    {
        //public double Lat { get { return Lat; } set { this.RunOnUiThread(() => { tvLat.Text = value.ToString(); }); } }
        //public double Lon { get { return Lon; } set { this.RunOnUiThread(() => { tvLon.Text = value.ToString(); GetAddress(Lat, value); }); } }
        TextView tvLat;
        TextView tvLon;
        TextView Addresstv;
        private LocListener ll;
        private LocationManager lm;
        Criteria cr;
        String bestProvider;
        //EditText etAddress;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            Button button = FindViewById<Button>(Resource.Id.myButton);
            button.Click += new EventHandler(button_Click);
            Button buttonStart = FindViewById<Button>(Resource.Id.startButton);
            buttonStart.Click += new EventHandler(buttonStart_Click);
            Addresstv = FindViewById<TextView>(Resource.Id.tvAddress);
            tvLat = FindViewById<TextView>(Resource.Id.tvlat);
            tvLon = FindViewById<TextView>(Resource.Id.tvlon);
            //Button btnLookup = FindViewById<Button>(Resource.Id.lookupAddress);
            //btnLookup.Click += new EventHandler(btnLookup_Click);
            //etAddress = FindViewById<EditText>(Resource.Id.address);
            Criteria cr = new Criteria();
            cr.Accuracy = Accuracy.Coarse;
            cr.PowerRequirement = Power.Low;
            cr.AltitudeRequired = false;
            cr.BearingRequired = false;
            cr.SpeedRequired = false;
            cr.CostAllowed = true;
            String serviceString = Context.LocationService;
            lm = (LocationManager)GetSystemService(serviceString);
            bestProvider = lm.GetBestProvider(cr, false);
            Location l = lm.GetLastKnownLocation(bestProvider);
            tvLat.Text = l.Latitude.ToString();
            tvLon.Text = l.Longitude.ToString();
            ll = new LocListener(this);
            lm.RequestLocationUpdates(bestProvider, 5000, 10f, this);
        }

        void btnLookup_Click(object sender, EventArgs e)
        {
            //var address = etAddress.Text.ToString();
            //Geocoder geocoder = new Geocoder(this, Java.Util.Locale.Default);
            //IList<Android.Locations.Address> result = geocoder.GetFromLocationName(address, 10);
            //if (result != null)
            //{
            //    tvLat.Text = result[0].Latitude.ToString();
            //    tvLon.Text = result[0].Longitude.ToString();
            //}
        }

        void GetAddress(double Lat, double Lon)
        {
            try
            {
                IList<Address> al;
                Geocoder geoc = new Geocoder(this, Java.Util.Locale.Default);
                al = geoc.GetFromLocation(Lat, Lon, 10);
                Addresstv.Text = String.Empty;

                if (al != null)
                {
                    for(int i = 0; i < al.Count; i++)
                    {
                        Addresstv.Text += String.Format("Location #{0}" + System.Environment.NewLine, i + 1);
                        if (!String.IsNullOrEmpty(al[i].GetAddressLine(0)) )
                            Addresstv.Text += al[i].GetAddressLine(0) + System.Environment.NewLine;
                        if (!String.IsNullOrEmpty(al[i].GetAddressLine(1)))
                            Addresstv.Text += al[i].GetAddressLine(1) + System.Environment.NewLine;
                        if (!String.IsNullOrEmpty(al[i].Locality))
                            Addresstv.Text += al[i].Locality + System.Environment.NewLine;
                        if (!String.IsNullOrEmpty(al[i].PostalCode))
                            Addresstv.Text += al[i].PostalCode + System.Environment.NewLine;
                    }
                }
                else
                {
                    Addresstv.Text = "No addresses found.";
                }
            }
            catch (System.Exception sysExc)
            {
                Addresstv.Text = sysExc.Message;
            }
        }
        void buttonStart_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(bestProvider))
            {
                cr = new Criteria();
                cr.Accuracy = Accuracy.Coarse;
                cr.PowerRequirement = Power.Low;
                cr.AltitudeRequired = false;
                cr.BearingRequired = false;
                cr.SpeedRequired = false;
                cr.CostAllowed = true;
                String serviceString = Context.LocationService;
                lm = (LocationManager)GetSystemService(serviceString);
                bestProvider = lm.GetBestProvider(cr, false);
            }
            lm.RequestLocationUpdates(bestProvider, 5000, 500f, this);
        }

        void button_Click(object sender, EventArgs e)
        {
            lm.RemoveUpdates(this);
        }

        public void OnLocationChanged(Location location)
        {
            this.RunOnUiThread(() => tvLat.Text = location.Latitude.ToString());
            this.RunOnUiThread(() => { 
                tvLon.Text = location.Longitude.ToString(); 
                GetAddress(location.Latitude, location.Longitude); 
            });
            //throw new NotImplementedException();
        }

        public void OnProviderDisabled(string provider)
        {
            //throw new NotImplementedException();
        }

        public void OnProviderEnabled(string provider)
        {
            //throw new NotImplementedException();
        }
        

        public void OnStatusChanged(string provider, Availability status, Bundle extras)
        {
            //throw new NotImplementedException();
        }
    }

}

