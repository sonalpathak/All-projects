using Android.App;
using Android.GoogleMaps;
using Android.OS;
using Android.Widget;

namespace MapExample
{
	[Activity (Label = "MapExample", MainLauncher = true)]
	public class Activity1 : MapActivity
	{
		MapView mapView;
		
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);
		}

		#region implemented abstract members of Android.GoogleMaps.MapActivity
		protected override bool IsRouteDisplayed {
			get {
				return false;
			}
		}
		#endregion
	}
}