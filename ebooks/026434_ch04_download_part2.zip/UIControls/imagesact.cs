using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    [Activity(Label = "Image Activity")]
    public class imagesact : Activity
    {
        Button btnImageClose;
        ImageButton ib;
        ImageView iv;
        Gallery g;
        Bundle _b;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            _b = bundle;
            SetContentView(Resource.Layout.images);
            btnImageClose = FindViewById<Button>(Resource.Id.btnImageClose);
            btnImageClose.Click += new EventHandler(btnClose_Click);
            g = FindViewById<Gallery>(Resource.Id.gal);
            TextView gtv = FindViewById<TextView>(Resource.Id.galtv);
            ib = FindViewById<ImageButton>(Resource.Id.ib);
            ib.SetImageResource(Resource.Drawable.blue);
            ib.Click += new EventHandler(ib_Click);
            ib.FocusChange += new EventHandler<View.FocusChangeEventArgs>(ib_FocusChange);
            iv = FindViewById<ImageView>(Resource.Id.iv);
            iv.SetImageResource(Resource.Drawable.desert);
            g.Adapter = new ImageAdapter(this);   
        }
        public override bool OnContextItemSelected(IMenuItem item) 
        {
            base.OnContextItemSelected(item);
            return(false);
        }
        public override bool OnCreateOptionsMenu(Android.Views.IMenu menu)
        {
            base.OnCreateOptionsMenu(menu);
            // Group Id
            int groupId = 0;
            // Unique menu item Identifier. Used for event handling.
            int menuItemId = Android.Views.Menu.First;
            // The order position of the item
            int menuItemOrder = Android.Views.Menu.None;
            // Text to be displayed for this menu item.
            int menuItemText = Resource.String.menuitem1;
            // Create the menu item and keep a reference to it.

            IMenuItem menuItem1 = menu.Add(groupId, menuItemId, menuItemOrder, menuItemText);
            menuItem1.SetShortcut('1', 'a');
            Java.Lang.ICharSequence str0 = new Java.Lang.String("Menu Item 1");
            Java.Lang.ICharSequence str1 = new Java.Lang.String("Menu Item 2");
            Java.Lang.ICharSequence str2 = new Java.Lang.String("Menu Item 3");
            Java.Lang.ICharSequence str3 = new Java.Lang.String("Menu Item 4");
            Java.Lang.ICharSequence str4 = new Java.Lang.String("Menu Item 5");
            Java.Lang.ICharSequence str5 = new Java.Lang.String("Menu Item 6");

            Int32 MenuGroup = 10;
            IMenuItem menuItem2 =
                menu.Add(MenuGroup, menuItemId + 10, menuItemOrder + 1, str0);
            IMenuItem menuItem3 =
                menu.Add(MenuGroup, menuItemId + 20, menuItemOrder + 2, str1);
            ISubMenu sub = menu.AddSubMenu(0, menuItemOrder + 30, menuItemOrder + 3, str2);
            sub.SetHeaderIcon(Resource.Drawable.plussign);
            sub.SetIcon(Resource.Drawable.plussign);
            IMenuItem submenuItem = sub.Add(0, menuItemId + 40, menuItemOrder + 4, str3);
            IMenuItem submenuItem2 =
                sub.Add(MenuGroup, menuItemId + 50, menuItemOrder + 5, str4).SetCheckable(true);
            IMenuItem submenuItem3 =
                sub.Add(MenuGroup, menuItemId + 60, menuItemOrder + 6, str5).SetCheckable(true);
            
            return true;
        }

        public override bool OnMenuItemSelected(int featureId, IMenuItem item)
        {
            switch (item.ItemId)
            {
                case(0):

                    return (true);

                case(1):

                    return (true);

            }
            return (false);
        }
        void g_Click(object sender, EventArgs e)
        {
            
        }

        void ib_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus)
            {
                ib.SetImageResource(Resource.Drawable.red);
            }
            else
            {
                ib.SetImageResource(Resource.Drawable.purple);
            }
        }

        void ib_Click(object sender, EventArgs e)
        {
            ib.SetImageResource(Resource.Drawable.purple);
        }

        void btnClose_Click(object sender, EventArgs e)
        {
            this.Finish();
            //Android.Util.DisplayMetrics dm = new Android.Util.DisplayMetrics();
        }
    }
}