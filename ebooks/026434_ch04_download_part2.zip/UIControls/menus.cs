using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    [Activity(Label = "Menus Activity")]
    public class menus : Activity
    {
        private ImageView ivc;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.menulayout);
            ivc = FindViewById<ImageView>(Resource.Id.ivc);
            ivc.SetImageResource(Resource.Drawable.desert);
            // Create your application here
            RegisterForContextMenu(ivc);

            // Create your application here
        }
        public override void OnCreateContextMenu(Android.Views.IContextMenu menu, View v,
            Android.Views.IContextMenuContextMenuInfo menuInfo)
        {
            base.OnCreateContextMenu(menu, v, menuInfo);
            MenuInflater inflater = new Android.Views.MenuInflater(this);
            inflater.Inflate(Resource.Layout.menu, menu);
            //menu.SetHeaderTitle("Embedded Context Menu");
        }

        //public override void OnCreateContextMenu(Android.Views.IContextMenu menu, View v,
        //        Android.Views.IContextMenuContextMenuInfo menuInfo)
        //{
        //    base.OnCreateContextMenu(menu, v, menuInfo);
        //    Java.Lang.ICharSequence str0 = new Java.Lang.String("Context Menu");
        //    Java.Lang.ICharSequence str1 = new Java.Lang.String("Item 1");
        //    Java.Lang.ICharSequence str2 = new Java.Lang.String("Item 2");
        //    Java.Lang.ICharSequence str3 = new Java.Lang.String("Item 3");
        //    Java.Lang.ICharSequence strSubMenu = new Java.Lang.String("Submenu");
        //    Java.Lang.ICharSequence strSubMenuItem = new Java.Lang.String("Submenu Item");
        //    menu.SetHeaderTitle(str0);
        //    menu.Add(0, Android.Views.Menu.First, 
        //        Android.Views.Menu.None, str1).SetIcon(Resource.Drawable.koala);
        //    menu.Add(0, Android.Views.Menu.First + 1, Android.Views.Menu.None, str2).SetCheckable(true);
        //    menu.Add(0, Android.Views.Menu.First + 2, Android.Views.Menu.None, str3)
        //        .SetShortcut('3', '3');
        //    ISubMenu sub = menu.AddSubMenu(strSubMenu);
        //    sub.Add(strSubMenuItem);
        //}

        public override bool OnContextItemSelected(IMenuItem item)
        {
            base.OnContextItemSelected(item);
            switch (item.ItemId)
            {
                case (0):

                    return (true);

                case (1):

                    return (true);

            }

            return (false);
        }
        // Uncomment this method if you want to load a menu from an xml file.
        //  At the same time, you will need to comment out the "other"
        //  
        //public override bool OnCreateOptionsMenu(Android.Views.IMenu menu)
        //{
        //    base.OnCreateOptionsMenu(menu);
        //    MenuInflater inflater = new Android.Views.MenuInflater(this);
        //    inflater.Inflate(Resource.Layout.menu, menu);
        //    return (true);
        //}
        public override bool OnCreateOptionsMenu(Android.Views.IMenu menu)
        {
            base.OnCreateOptionsMenu(menu);
            int groupId = 0;
            int menuItemId = Android.Views.Menu.First;
            int menuItemOrder = Android.Views.Menu.None;
            // Text to be displayed for this menu item.
            int menuItemText = Resource.String.menuitem1;
            // Create the menu item and keep a reference to it.
            IMenuItem menuItem1 = menu.Add(groupId, menuItemId, menuItemOrder, menuItemText);
            menuItem1.SetShortcut('1', 'a');
            Int32 MenuGroup = 10;
            IMenuItem menuItem2 =
                menu.Add(MenuGroup, menuItemId + 10, menuItemOrder + 1, 
                new Java.Lang.String("Menu Item 2"));
            IMenuItem menuItem3 =
                menu.Add(MenuGroup, menuItemId + 20, menuItemOrder + 2, 
                new Java.Lang.String("Menu Item 3"));
            ISubMenu sub = menu.AddSubMenu(0, menuItemOrder + 30, menuItemOrder + 3, 
                new Java.Lang.String("Submenu 1"));
            sub.SetHeaderIcon(Resource.Drawable.plussign);
            sub.SetIcon(Resource.Drawable.plussign);
            IMenuItem submenuItem = sub.Add(0, menuItemId + 40, menuItemOrder + 4, 
                new Java.Lang.String("Submenu Item"));
            IMenuItem submenuItem2 =
                sub.Add(MenuGroup, menuItemId + 50, menuItemOrder + 5, 
                new Java.Lang.String("sub-1")).SetCheckable(true);
            IMenuItem submenuItem3 =
                sub.Add(MenuGroup, menuItemId + 60, menuItemOrder + 6, 
                new Java.Lang.String("sub-2")).SetCheckable(true);

            return true;
        }

        public override bool OnMenuItemSelected(int featureId, IMenuItem item)
        {
            base.OnMenuItemSelected(featureId, item);
            switch (item.ItemId)
            {
                case (0):

                    return (true);

                case (1):

                    return (true);

            }
            return (false);
        }

    }
}