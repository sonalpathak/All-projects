using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    [Activity(Label = "TextView Activity", Name = "uicontrols.textviewact")]
    public class textviewact : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Create your application here
            SetContentView(Resource.Layout.textviewact);
            Button btn = FindViewById<Button>(Resource.Id.GetValues);
            btn.Click += new EventHandler(btn_Click);
        }

        void btn_Click(object sender, EventArgs e)
        {
            TextView tv = FindViewById<TextView>(Resource.Id.tv);
            EditText et = FindViewById<EditText>(Resource.Id.ExampleEditText);
            tv.Text = et.Text;
        }
    }
}