using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    public class ImageAdapter : BaseAdapter
    {
        Context context;
        Dictionary<int, ImageView> dict;
        public ImageAdapter(Context c) { context = c; dict = new Dictionary<int, ImageView>(); }

        public override int Count { get { return thumbIds.Length; } }

        public override Java.Lang.Object GetItem(int position){ return null; }

        public override long GetItemId(int position){ return 0; }

        // create a new ImageView for each item referenced by the Adapter
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            bool bOut;
            ImageView i;// = new ImageView(context);
            bOut = dict.TryGetValue(position, out i);

            if (bOut == false)
            {
                i = new ImageView(context);
                i.SetImageResource(thumbIds[position]);
                i.LayoutParameters = new Gallery.LayoutParams(150, 100);
                i.SetScaleType(ImageView.ScaleType.CenterInside);
                dict.Add(position, i);
            }

            return i;
        }

        // references to our images
        int[] thumbIds = {
            Resource.Drawable.chrysanthemum,
            Resource.Drawable.desert,
            Resource.Drawable.hydrangeas,
            Resource.Drawable.jellyfish,
            Resource.Drawable.koala,
            Resource.Drawable.lighthouse
        };
    }
}