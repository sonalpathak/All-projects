using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    [Activity(Label = "Spinner Activity")]
    public class spinneract : Activity
    {
        Spinner state;
        TextView tvSp;
        ArrayAdapter<String> aas;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.spinner);

            state = FindViewById<Spinner>(Resource.Id.Sp);
            tvSp = FindViewById<TextView>(Resource.Id.tvSp);
            aas = new ArrayAdapter<String>(this, 
                Android.Resource.Layout.SimpleSpinnerDropDownItem);
            aas.Add(String.Empty);
            aas.Add("Alabama");
            aas.Add("Arizona");
            aas.Add("California");
            aas.Add("Tennessee");
            aas.Add("Texas");
            aas.Add("Washington");
            state.Adapter = aas;
            state.ItemSelected += new EventHandler<ItemEventArgs>(sp_ItemSelected);
        }

        void sp_ItemSelected(object sender, ItemEventArgs e)
        {
            tvSp.Text = Convert.ToString(aas.GetItem(e.Position));
        }
    }
}