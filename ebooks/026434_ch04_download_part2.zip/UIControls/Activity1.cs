﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace uicontrols
{
    [Activity(Label = "UI Controls", MainLauncher = true)]
    public class Activity1 : Activity
    {
        EditText txt;
        Button btnCloseAct;
        TextView tv;
        
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" Layout resource
            SetContentView(Resource.Layout.main);

            // Get our button from the Layout resource,
            // and attach an event to it
            Button button = FindViewById<Button>(Resource.Id.myButton);
            button.Click += new EventHandler(button_Click);
            Button btnrbcb = FindViewById<Button>(Resource.Id.btnRadioCheckBoxes);
            btnrbcb.Click += new EventHandler(btnrbcb_Click);
            Button btnImg = FindViewById<Button>(Resource.Id.btnImages);
            btnImg.Click += new EventHandler(btnImg_Click);
            Button btnTime = FindViewById<Button>(Resource.Id.btnLoadDates);
            btnTime.Click += new EventHandler(btnTime_Click);
            Button btnSpinner = FindViewById<Button>(Resource.Id.btnSpinner);
            btnSpinner.Click += new EventHandler(btnSpinner_Click);
            Button btnOpenMenus = FindViewById<Button>(Resource.Id.btnOpenMenus);
            btnOpenMenus.Click += new EventHandler(btnOpenMenus_Click);
            btnCloseAct = FindViewById<Button>(Resource.Id.btnCloseAct);
            btnCloseAct.Click += new EventHandler(btnCloseAct_Click);
        }

        void btnCloseAct_Click(object sender, EventArgs e)
        {
            this.Finish();
        }

        void btnOpenMenus_Click(object sender, EventArgs e)
        {
            Intent i = new Intent();
            i.SetClass(this, typeof(menus));
            i.AddFlags(ActivityFlags.NewTask);
            StartActivity(i);
        }

        void btnSpinner_Click(object sender, EventArgs e)
        {
            Intent i = new Intent();
            i.SetClass(this, typeof(spinneract));
            i.AddFlags(ActivityFlags.NewTask);
            StartActivity(i);
        }

        void btnTime_Click(object sender, EventArgs e)
        {
            Intent i = new Intent();
            i.SetClass(this, typeof(timeact));
            i.AddFlags(ActivityFlags.NewTask);
            StartActivity(i);
        }

        void btnImg_Click(object sender, EventArgs e)
        {
            Intent i = new Intent();
            i.SetClass(this, typeof(imagesact));
            i.AddFlags(ActivityFlags.NewTask);
            StartActivity(i);            
        }

        void btnrbcb_Click(object sender, EventArgs e)
        {
            Intent i = new Intent();

            i.SetClassName(this, "uicontrols.radiocheckboxes");
            i.AddFlags(ActivityFlags.NewTask);
            StartActivity(i);
        }

        void btnKeyb_Click(object sender, EventArgs e)
        {
            
        }

        void button_Click(object sender, EventArgs e)
        {
            Intent i = new Intent();
            i.SetClassName(this, "uicontrols.textviewact");
            i.AddFlags(ActivityFlags.NewTask);
            StartActivity(i);
        }

        void txt_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus == false)
            {
                Android.Views.InputMethods.InputMethodManager imm = (Android.Views.InputMethods.InputMethodManager)GetSystemService(Context.InputMethodService);
                imm.HideSoftInputFromWindow(txt.WindowToken, Android.Views.InputMethods.HideSoftInputFlags.None);
            }
        }

        void btn_Click(object sender, EventArgs e)
        {
            tv.Text = txt.Text;
            Android.Views.InputMethods.InputMethodManager imm = (Android.Views.InputMethods.InputMethodManager)GetSystemService(Context.InputMethodService);
            imm.HideSoftInputFromWindow(txt.WindowToken, Android.Views.InputMethods.HideSoftInputFlags.None);
        }
    }
}

