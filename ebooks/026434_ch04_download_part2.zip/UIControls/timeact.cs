using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    [Activity(Label = "Time Activity")]
    public class timeact : Activity
    {
        Button btnClose, btnTimeValues;
        int nowHour, nowMinute;
        TimePicker tp;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.time);
            btnClose = FindViewById<Button>(Resource.Id.btnTimeClose);
            btnClose.Click += new EventHandler(btnClose_Click);
            btnTimeValues = FindViewById<Button>(Resource.Id.btnTimeValues);
            btnTimeValues.Click += new EventHandler(btnTimeValues_Click);
            nowHour = DateTime.Now.Hour;
            nowMinute = DateTime.Now.Minute;
            tp = FindViewById<TimePicker>(Resource.Id.tp);
            tp.TimeChanged += new EventHandler<TimePicker.TimeChangedEventArgs>(tp_TimeChanged);
            // Create your application here
        }

        void tp_TimeChanged(object sender, TimePicker.TimeChangedEventArgs e)
        {
            this.nowHour = e.HourOfDay;
            this.nowMinute = e.Minute;
        }

        void btnTimeValues_Click(object sender, EventArgs e)
        {
            TextView tv = FindViewById<TextView>(Resource.Id.dctv);
            DigitalClock dc = FindViewById<DigitalClock>(Resource.Id.dc);
            tv.Text = dc.Text;
            TextView tptv = FindViewById<TextView>(Resource.Id.tptv);
            DatePicker dp = FindViewById<DatePicker>(Resource.Id.dp);
            TextView dptv = FindViewById<TextView>(Resource.Id.dptv);
            DateTime dt = new DateTime(dp.Year, dp.Month + 1, dp.DayOfMonth, nowHour, nowMinute, 0);
            dptv.Text = dt.ToString();
        }

        void btnClose_Click(object sender, EventArgs e)
        {
            this.Finish();
        }
    }
}