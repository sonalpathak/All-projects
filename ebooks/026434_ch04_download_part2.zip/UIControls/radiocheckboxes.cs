using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace uicontrols
{
    [Activity(Label = "Radio & Checkboxes", Name="uicontrols.radiocheckboxes")]
    public class radiocheckboxes : Activity
    {
        Button btn;
        RadioButton rb;
        CheckBox cb;
        RadioGroup rg;
        TextView rbtv, cbtv, rgtv;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.radiocheckboxes);
            // Create your application here
            rg = FindViewById<RadioGroup>(Resource.Id.rg);
            rg.Click += new EventHandler(rg_Click);
            cb = FindViewById<CheckBox>(Resource.Id.cb1);
            rb = FindViewById<RadioButton>(Resource.Id.rb);
            btn = FindViewById<Button>(Resource.Id.btnCloseRadioCheckBoxes);
            rbtv = FindViewById<TextView>(Resource.Id.rbtv);
            cbtv = FindViewById<TextView>(Resource.Id.tvcb);
            rgtv = FindViewById<TextView>(Resource.Id.rgtv);
            btn.Click += new EventHandler(btn_Click);
            cb.Click += new EventHandler(cb_Click);
            rb.Click += new EventHandler(rb_Click);
            RadioButton rb1;
            for (int i = 0; i < 3; i++)
            {
                rb1 = new RadioButton(this);
                rb1.Text = "Item " + i.ToString();
                rb1.Click += new EventHandler(rb1_Click);
                rg.AddView(rb1, i);
            }

        }

        void rg_Click(object sender, EventArgs e)
        {
            rgtv.Text = ((RadioButton)sender).Text;
        }

        public override bool OnCreateOptionsMenu(Android.Views.IMenu menu)
        {
            base.OnCreateOptionsMenu(menu);
            Java.Lang.ICharSequence str0 = new Java.Lang.String("Menu Item 1");
            Java.Lang.ICharSequence str1 = new Java.Lang.String("Menu Item 2");
            Java.Lang.ICharSequence str2 = new Java.Lang.String("Menu Item 3");
            Java.Lang.ICharSequence str3 = new Java.Lang.String("Menu Item 4");
            Java.Lang.ICharSequence str4 = new Java.Lang.String("Menu Item 5");
            Java.Lang.ICharSequence str5 = new Java.Lang.String("Menu Item 6");
            Java.Lang.ICharSequence str6 = new Java.Lang.String("Menu Item 7");
            Java.Lang.ICharSequence str7 = new Java.Lang.String("Menu Item 8");
            Java.Lang.ICharSequence str8 = new Java.Lang.String("Menu Item 9");
            
            int MenuItemId = Android.Views.Menu.None;
            int MenuGroup = 10;
            IMenuItem menuItem2 =
                menu.Add(MenuGroup, MenuItemId, MenuItemId, str0);
            IMenuItem menu2 = menu.Add(MenuGroup, MenuItemId, MenuItemId, str1);
            IMenuItem menuItem3 =
                menu.Add(MenuGroup, MenuItemId + 1, MenuItemId + 1, str2);
            IMenuItem menuItem4 =
                menu.Add(MenuGroup, MenuItemId + 2, MenuItemId + 2, str3);
            IMenuItem menuItem5 =
                menu.Add(MenuGroup, MenuItemId + 3, MenuItemId + 3, str4);
            IMenuItem menuItem6 =
                menu.Add(MenuGroup, MenuItemId + 4, MenuItemId + 4, str5);
            IMenuItem menuItem7 =
                menu.Add(MenuGroup, MenuItemId + 5, MenuItemId + 5, str6);
            IMenuItem menuItem8 =
                menu.Add(MenuGroup, MenuItemId + 6, MenuItemId + 6, str7);
            IMenuItem menuItem9 =
                menu.Add(MenuGroup, MenuItemId + 7, MenuItemId + 7, str8);
            
            return true;
        }

        void rb1_Click(object sender, EventArgs e)
        {
            RadioButton rb1 = (RadioButton)sender;
            rgtv.Text = rb1.Text + " was clicked.";
        }

        void rb_Click(object sender, EventArgs e)
        {
            rbtv.Text = "Radio Button Click";
        }

        void cb_Click(object sender, EventArgs e)
        {
            CheckBox cb = (CheckBox)sender;
            if (cb.Checked == true)
            {
                cbtv.Text = "Checkbox Clicked";
            }
            else
            {
                cbtv.Text = "Checkbox Not Clicked";
            }
        }

        void btn_Click(object sender, EventArgs e)
        {
            this.Finish();
        }
    }
}