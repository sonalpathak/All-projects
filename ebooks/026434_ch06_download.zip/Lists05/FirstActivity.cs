﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace Lists05
{
	[Activity(Label = "Nested Lists", MainLauncher = true)]
	public class FirstActivity : ListActivity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			
			this.ListAdapter = new ArrayAdapter<string>(
				this,
				Android.Resource.Layout.SimpleListItem1,
				new string[] {
					"Item One", "Item Two", "Item Three",
					"Item Four", "Item Five", "Item Six",
					"Item Seven", "Item Eight", "Item Nine"
				}
			);

			this.ListView.ItemClick += delegate
			{
				StartActivity(typeof(SecondActivity));
			};

			this.ListView.ItemLongClick += (sender, e) => {

				string sel = this.ListAdapter.GetItem(e.Position).ToString();

				var secondIntent = new Android.Content.Intent(this, typeof(SecondActivity));
				secondIntent.PutExtra("selected", sel + " was Selected!");
				StartActivity(secondIntent);

			};
		}
	}
}

