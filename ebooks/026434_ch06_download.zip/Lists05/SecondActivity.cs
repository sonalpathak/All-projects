using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Lists05
{
	[Activity(Label = "Second Activity")]
	public class SecondActivity : ListActivity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			string sel = this.Intent.GetStringExtra("selected");

			if (sel == null)
				sel = "Second Activity!";

			this.ListAdapter = new ArrayAdapter<string>(
				this,
				Android.Resource.Layout.SimpleListItem1,
				new string[] { sel }
			);
		}
	}
}