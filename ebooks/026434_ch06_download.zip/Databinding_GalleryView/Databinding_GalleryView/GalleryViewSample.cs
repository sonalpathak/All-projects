﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Database;
using Android.Provider;

namespace Databinding_GalleryView
{
	[Activity(Label = "Gallery View Sample", MainLauncher = true)]
	public class GalleryViewSample : Activity
	{

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.Main);

			CreateGallery();
		}

		private void CreateGallery()
		{
			Gallery g = FindViewById<Gallery>(Resource.Id.targetGallery);
			g.Adapter = new ImageAdapter(this);
		}
	}

	public class ImageAdapter: BaseAdapter
	{
		private Context _Context;

		private ICursor _ImageCursor;
		protected ICursor ImageCursor
		{
			get {
				if (_ImageCursor == null)
				{
					_ImageCursor = GetImageCursor();
				}

				return _ImageCursor;
			}
			set { _ImageCursor = value; }
		}

		public ImageAdapter(Context c)
		{
            
			_Context = c;
		}

		private ICursor GetImageCursor()
		{
			string[] Projection = { MediaStore.Images.ImageColumns.Id };
			var ImageCursor = ((Activity)_Context).ManagedQuery(MediaStore.Images.Media.ExternalContentUri, Projection, null, null, null);

			return ImageCursor;
		}

		public override int Count
		{
			get { return ImageCursor.Count; }
		}

		public override Java.Lang.Object GetItem(int position)
		{
			return position;
		}

		public override long GetItemId(int position)
		{
		ImageCursor.MoveToPosition(position);
			var ImageID = ImageCursor.GetString(0);

			return position;
		}

		public override View GetView(int position, View convertView, ViewGroup parent)
		{
			if (convertView == null)
			{
				ImageView returnView = new ImageView(_Context);
				ImageCursor.MoveToPosition(position);
				
				var ImageID = ImageCursor.GetString(0);
				returnView.SetImageURI(Android.Net.Uri.WithAppendedPath(MediaStore.Images.Media.ExternalContentUri, ImageID));
				returnView.SetScaleType(ImageView.ScaleType.CenterCrop);
				return returnView;
			}
			else
			{
				return (ImageView)convertView;
			}
		}

	}

}



