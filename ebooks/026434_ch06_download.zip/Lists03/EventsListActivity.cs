﻿using System;
using Android.App;
using Android.OS;
using Android.Widget;
using Android.Views;

namespace Lists03
{
	[Activity(Label = "Events List", MainLauncher=true)]
	public class EventsListActivity : ListActivity
	{
		private string[] items;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			items = new string[] { "Item 1", "Item 2", "Item 3" };
			this.ListAdapter = new ArrayAdapter<string>(this,
				Android.Resource.Layout.SimpleListItem1, items);

			//Using an EventHandler
			this.ListView.ItemClick += new EventHandler<ItemEventArgs>(
				ListView_ItemClick);

			//Using an Anonymous Method
			this.ListView.ItemLongClick += delegate(object sender, Android.Widget.AdapterView.ItemLongClickEventArgs e)
			{
				Toast.MakeText(this,
					"Long Click: " + items[e.Position], ToastLength.Short).Show();
			};

			//Using a Lambda Expression
			this.ListView.Recycler += (object sender, 
				AbsListView.RecyclerEventArgs e) =>
			{
				Toast.MakeText(this, "Recycler!", ToastLength.Short).Show();
			};
		}

		void ListView_ItemClick(object sender, ItemEventArgs e)
		{
			Toast.MakeText(this, "Click: " + items[e.Position], ToastLength.Short).Show();
		}
	}
}
