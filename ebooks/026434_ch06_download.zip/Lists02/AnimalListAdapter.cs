using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;

namespace Lists02
{
	public class AnimalListAdapter : BaseAdapter<Animal>
	{
		Activity context;
		public List<Animal> Animals;

		public AnimalListAdapter(Activity context, List<Animal> animals)
			: base()
		{
			this.context = context;
			this.Animals = animals;
		}

		public override int Count
		{
			get { return this.Animals.Count; }
		}

		public override Animal this[int position]
		{
			get { return this.Animals[position]; }
		}

		public override View GetView(int position, View convertView, ViewGroup parent)
		{
			//Get our object for this position
			var item = this.Animals[position];

			//Try to reuse convertView if it's not  null, otherwise inflate it from our item layout
			// This gives us some performance gains by not always inflating a new view
			// This will sound familiar to MonoTouch developers with UITableViewCell.DequeueReusableCell()
			var view = convertView;

			if (convertView == null || !(convertView is LinearLayout))
				view = context.LayoutInflater.Inflate(Resource.Layout.AnimalItem, parent, false);

			//Find references to each subview in the list item's view
			var imageItem = view.FindViewById(Resource.Id.imageItem) as ImageView;
			var textTop = view.FindViewById(Resource.Id.textTop) as TextView;
			var textBottom = view.FindViewById(Resource.Id.textBottom) as TextView;

			//Assign this item's values to the various subviews
			imageItem.SetImageResource(item.Image);
			textTop.SetText(item.Name, TextView.BufferType.Normal);
			textBottom.SetText(item.Description, TextView.BufferType.Normal);

			//Finally return the view
			return view;
		}

		public override long GetItemId(int position)
		{
			return position;
		}
	}
}
