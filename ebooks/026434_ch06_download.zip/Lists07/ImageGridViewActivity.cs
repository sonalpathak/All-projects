﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Graphics.Drawables;

namespace Lists07
{
	[Activity(Label = "GridView", MainLauncher = true)]
	public class ImageGridViewActivity : Activity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.Gridview);

			// Get our button from the layout resource,
			// and attach an event to it
			var gridView = this.FindViewById<GridView>(Resource.Id.gridview);

			var ia = new ImageAdapter(this);
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.Battery));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.Computer));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.DriveCDROM));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.DriveHardDisk));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.DriveRemovableMedia));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.InputKeyboard));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.InputMouse));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.MediaCDROM));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.MediaCDROMAudio));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.MediaCDRW));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.MediaDVD));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.MediaDVDRW));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.MediaFloppy));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.Printer));
			ia.Images.Add(Resources.GetDrawable(Resource.Drawable.VideoDisplay));

			gridView.Adapter = ia;
		}
	}
}

