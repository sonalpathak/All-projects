using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Lists07
{
	public class ImageAdapter : BaseAdapter<Drawable>
	{
		Context context;

		public ImageAdapter(Context context) : base()
		{
			this.context = context;
			this.Images = new List<Drawable>();
		}

		public List<Drawable> Images
		{
			get;
			set;
		}

		public override int Count
		{
			get { return this.Images.Count; }
		}
		public override Drawable this[int position]
		{
			get { return this.Images[position]; }
		}

		public override long GetItemId(int position)
		{
			return position;
		}

		
		public override View GetView(int position, View convertView, ViewGroup parent)
		{
			ImageView imageView;

			if (convertView == null)
				imageView = new ImageView(context);
			else
				imageView = (ImageView)convertView;

			imageView.SetImageDrawable(this.Images[position]);

			return imageView;
		}
	}
}