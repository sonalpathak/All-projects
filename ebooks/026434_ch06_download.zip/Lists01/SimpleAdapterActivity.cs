using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Lists01
{
	[Activity(Label = "SimpleAdapter", MainLauncher=true, LaunchMode=Android.Content.PM.LaunchMode.SingleTask)]
	public class SimpleAdapterActivity : ListActivity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			//Create our sample data
			var items = new List<IDictionary<string, object>>();

			var item1 = new Dictionary<string, object>();
			item1.Add("simpleAdapterTitle", "First Title");
			item1.Add("simpleAdapterDesc", "This is a Description");

			var item2 = new Dictionary<string, object>();
			item2.Add("simpleAdapterTitle", "Second Title");
			item2.Add("simpleAdapterDesc", "Another Description");

			items.Add(item1);
			items.Add(item2);
			
			//Create the Adapter from the sample data
			var a = new SimpleAdapter(this,
				items,
				Android.Resource.Layout.SimpleListItem2,
				new string[] 
				{ 
					"simpleAdapterTitle", 
					"simpleAdapterDesc" 
				},
				new int[] 
				{ 
					Android.Resource.Id.Text1,
					Android.Resource.Id.Text2
				});

			this.ListAdapter = a;
		}
	}
}