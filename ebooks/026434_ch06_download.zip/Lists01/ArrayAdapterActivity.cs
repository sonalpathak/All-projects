﻿using System;
using System.Linq;
using System.Collections.Generic;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace Lists01
{
	[Activity(Label = "ArrayAdapter", MainLauncher = true, LaunchMode = Android.Content.PM.LaunchMode.SingleTask)]
	public class ArrayAdapterActivity : ListActivity
	{
		public List<Animal> Animals
		{
			get;
			set;
		}

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			this.Animals = new List<Animal>();
			this.Animals.Add(new Animal() { Name = "Dog" });
			this.Animals.Add(new Animal() { Name = "Cat" });
			this.Animals.Add(new Animal() { Name = "Hippo" });

			var adapter = new ArrayAdapter<string>(this,
				Android.Resource.Layout.SimpleListItem1,
				(from animal in this.Animals select animal.Name).ToArray());

			this.ListAdapter = adapter;
		}
	}
}

