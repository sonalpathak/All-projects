﻿using System;
using Android.App;
using Android.OS;
using Android.Widget;

namespace Lists01
{
	[Activity(MainLauncher = true, Label = "SimpleList", LaunchMode = Android.Content.PM.LaunchMode.SingleTask)]
	public class SimpleListActivity : ListActivity
	{
		string[] items;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			//Create a list of items to show
			items = new string[] {
				"Item One",
				"Second Item",
				"Number Three",
				"Fourth Option",
				"Fifth One",
				"Sixth Item",
				"Number Seven",
				"This is Eight",
				"Nine",
				"Ten Speed"
			};

			//Make an ArrayAdapter using the built in
			//	SimpleListItem1 layout and our items array
			this.ListAdapter = new ArrayAdapter<string>(
				this,
				Android.Resource.Layout.SimpleListItem1,
				items);
		}
	}
}
