﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Preferences;

namespace Lists04
{
	[Activity(Label = "Prefs", MainLauncher = true)]
	public class Preferences : PreferenceActivity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			this.AddPreferencesFromResource(Resource.Layout.Preferences);

			var listPref = (this.FindPreference("listChoice") as ListPreference);

			listPref.SetEntries(new string[] { "Choice #1", "Option No. 2", "3rd" });
			listPref.SetEntryValues(new string[] { "1", "2", "3" });
		}
	}
}
