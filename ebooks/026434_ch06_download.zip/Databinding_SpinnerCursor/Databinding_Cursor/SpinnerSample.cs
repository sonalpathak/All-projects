﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Database;
using Android.Provider;
using Android.Util;

namespace Databinding_Cursor
{
	[Activity(Label = "Spinner Sample", MainLauncher = true)]
	public class SpinnerSample : Activity
	{
		int LastSpinnerSelectedPosition;

		private ICursor _BookmarkCursor;
		public ICursor BookmarkCursor 
		{
			get {
				if (_BookmarkCursor == null)
				{
					_BookmarkCursor = GetBookmarkCursor();
				}
				return _BookmarkCursor;
			}
			set { _BookmarkCursor = value; }
		}

		public ICursor GetBookmarkCursor()
		{
			return ManagedQuery(Browser.BookmarksUri, new String[] {Browser.BookmarkColumns.Title, Browser.BookmarkColumns.Url, Browser.BookmarkColumns.InterfaceConsts.Id }, null, null, null);
		}

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			SetContentView(Resource.Layout.Main);

			CreateSpinner();
		}

		public void CreateSpinner()
		{
			// Since the spinner is just being created, set this
			// tracking var to 0.
			LastSpinnerSelectedPosition = 0;

			var targetSpinner = FindViewById<Spinner>(Resource.Id.spinner);
			var SpinnerAdapter = new SimpleCursorAdapter(this,
							Android.Resource.Layout.SimpleListItem1,
							BookmarkCursor,
							new string[] { Browser.BookmarkColumns.Title },
							new int[] { Android.Resource.Id.Text1 });
			
			SpinnerAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
			targetSpinner.Adapter = SpinnerAdapter;
			targetSpinner.Prompt = "Select...";

			targetSpinner.ItemSelected += new EventHandler<ItemEventArgs>(SpinnerItemSelected);
		}

		public void SpinnerItemSelected(object sender, ItemEventArgs e)
		{
			var CurrentSpinner = ((Spinner)sender);
			var CurrentSelectedIndex = CurrentSpinner.SelectedItemPosition;

			if (CurrentSelectedIndex != LastSpinnerSelectedPosition)
			{
				//  The Selected Item in a spinner is actually the 
				//  underlying cursor object w/ the position set to the 
				//  appropriate index.  Cast to ICursor to access.
				ICursor selectedItem = (ICursor)CurrentSpinner.SelectedItem;

				var URLColumnIndex = selectedItem.GetColumnIndex(Browser.BookmarkColumns.Url);
				var URL = selectedItem.GetString(URLColumnIndex);

				//  In order to open a new browser, we need to create the appropriate intent
				//  and then start a new activity using that intent.
				Intent BrowserIntent = new Intent(Intent.ActionView);
				BrowserIntent.SetData(Android.Net.Uri.Parse(URL));

				StartActivity(BrowserIntent);

				LastSpinnerSelectedPosition = CurrentSelectedIndex;
			}
		}
	}
}

