using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Chapter11.Alarms
{
	[BroadcastReceiver]
	[IntentFilter(new string[] { "android.intent.action.BOOT_COMPLETED" }, 
		Categories=new string[] { "android.intent.category.HOME" })]
	public class BootBroadcastReceiver : BroadcastReceiver
	{
		public override void OnReceive(Context context, Intent intent)
		{
			var alarmManager = context.GetSystemService(Context.AlarmService) as AlarmManager;

			var serviceIntent = new Intent(context, typeof(TweetSearchService));

			alarmManager.SetInexactRepeating(AlarmType.Rtc,
				0, AlarmManager.IntervalFifteenMinutes,
				PendingIntent.GetService(context,
				0, serviceIntent, PendingIntentFlags.CancelCurrent));
		}
	}
}