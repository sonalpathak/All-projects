﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace Chapter11.Alarms
{
	[Activity(Label = "CH11 Alarms", MainLauncher = true)]
	public class MainActivity : Activity
	{
		bool enabled = false;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			SetContentView(Resource.Layout.Main);

			Button button = FindViewById<Button>(Resource.Id.myButton);
			button.Text = "Enable Alarm";

			button.Click += delegate 
			{
				enabled = !enabled;

				if (enabled)
				{
					var alarmManager = this.GetSystemService(Context.AlarmService) as AlarmManager;

					var serviceIntent = new Intent(this, typeof(TweetSearchService));

					alarmManager.SetInexactRepeating(AlarmType.Rtc,
						0, AlarmManager.IntervalFifteenMinutes,
						PendingIntent.GetService(this,
						0, serviceIntent, PendingIntentFlags.CancelCurrent));

					Toast.MakeText(this, "Alarm Set for 15 Minute Interval, for TweetSearchService!",
						ToastLength.Short).Show();
				}
				else
				{
					var alarmManager = this.GetSystemService(Context.AlarmService) as AlarmManager;

					var serviceIntent = new Intent(this, typeof(TweetSearchService));
					alarmManager.Cancel(
						PendingIntent.GetService(this, 0, serviceIntent, 
						PendingIntentFlags.CancelCurrent));

					Toast.MakeText(this, "Alarm Cancelled for TweetSearchService!",
						ToastLength.Short).Show();
				}

				button.Text = enabled ? "Disable Alarm" : "Enable Alarm";
			};
		}
	}
}

