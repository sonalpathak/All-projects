﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Content.PM;

namespace Chapter11.Notifications
{
	[Activity(Label = "CH11 Notifications", MainLauncher = true)]
	public class MainActivity : Activity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.Main);

			// Get our button from the layout resource,
			// and attach an event to it
			Button button = FindViewById<Button>(Resource.Id.myButton);
			button.Text = "Create Notification";

			button.Click += delegate 
			{
				RunOnUiThread(() => { CreateNotification(); });
			};
		}

		public void CreateNotification()
		{
			var notificationManager = GetSystemService(Context.NotificationService) as NotificationManager;
			//var notificationManager = NotificationManager.FromContext(this);

			var notification = new Notification(Android.Resource.Drawable.SymActionEmail,
				"Notification ticker...");

			notification.Vibrate = new long[] { 100, 200, 300 };
			notification.Number = 2;
			notification.LedOnMS = 1000;
			notification.LedOffMS = 2000;
			notification.Flags = NotificationFlags.AutoCancel | NotificationFlags.ShowLights;

			var intent = new Intent(this, typeof(MainActivity));

			var pendingIntent = PendingIntent.GetActivity(this, 
				0, intent, PendingIntentFlags.UpdateCurrent);

			notification.SetLatestEventInfo(this,
				"Notification Title",
				"Notification description...",
				pendingIntent);

			notificationManager.Notify(1, notification);
		}
	}
}

