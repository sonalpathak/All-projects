using System;
using System.Threading;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Chapter11.Twitter;

namespace Chapter11.ManualThreading
{
	[Service]
	public class ThreadedService : Service
	{
		int startCount = 0;
		Thread worker = null;
		Handler handler = new Handler();

		public override IBinder OnBind(Intent intent)
		{
			throw new NotImplementedException();
		}

		public override StartCommandResult OnStartCommand(Intent intent, 
			StartCommandFlags flags, int startId)
		{
			var startCmdResult = base.OnStartCommand(intent, flags, startId);

			startCount++;
		
			if (worker == null || !worker.IsAlive)
			{
				worker = new Thread(new ThreadStart(serviceWorker));
				worker.Start();
			}

			return startCmdResult;
		}
		
		void serviceWorker()
		{
			while (startCount > 0)
			{
				startCount--;

				var tweets = Search.SearchTweets(0, "#MonoDroid");

				foreach (var tweet in tweets)
					Android.Util.Log.Info("CHAPTER-11", string.Format(
						"{0} - {1}: {2}", tweet.Id, tweet.FromUser, tweet.Text));

				handler.Post(() =>
				{
					Toast.MakeText(this, "Tweets Refreshed!", 
						ToastLength.Short).Show();
				});
			}

			this.StopSelf();
		}
	}
}