using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;

namespace Chapter11.UICommunication
{
	[Activity(Label = "CH11 UI Broadcast Rec", MainLauncher=true,
		LaunchMode = Android.Content.PM.LaunchMode.SingleTask)]
	public class BroadcastActivity : Activity
	{
		const string ACTION_NEW_TWEETS = "action.NEW_TWEETS";

		ActivityBroadcastReceiver broadcastReceiver;
		Button buttonNewestId;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			SetContentView(Resource.Layout.Main);

			buttonNewestId = FindViewById<Button>(Resource.Id.myButton);
			buttonNewestId.Click += delegate
			{
				StartService(new Intent(this, typeof(BroadcastService)));
			};

			broadcastReceiver = new ActivityBroadcastReceiver();
			broadcastReceiver.Receive += (Context context, Intent intent) =>
			{
				var lastSinceId = intent.GetLongExtra("oldSinceId", 0);
				var tweets = Twitter.Search.SearchTweets(lastSinceId, "#MonoDroid");

				foreach (var tweet in tweets)
					Android.Util.Log.Info("CHAPTER-11", string.Format(
						"{0} - {1}: {2}", tweet.Id, tweet.FromUser, tweet.Text));

				Toast.MakeText(this, "Tweets Refreshed!", ToastLength.Short).Show();
			};
		}

		protected override void OnResume()
		{
			base.OnResume();

			RegisterReceiver(broadcastReceiver, 
				new IntentFilter(ACTION_NEW_TWEETS));
		}

		protected override void OnPause()
		{
			UnregisterReceiver(broadcastReceiver);

			base.OnPause();
		}
	}

	public class ActivityBroadcastReceiver : BroadcastReceiver
	{
		public event Action<Context, Intent> Receive;

		public override void OnReceive(Context context, Intent intent)
		{
			if (this.Receive != null)
				this.Receive(context, intent);
		}
	}
}