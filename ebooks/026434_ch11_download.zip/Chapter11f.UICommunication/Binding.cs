using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Chapter11.Twitter;

namespace Chapter11.UICommunication
{
	[Service]
	public class BindingTweetService : IntentService
	{
		public event Action NewTweetsFound;

		public List<Tweet> Tweets { get; set; }
		public long LastSinceId { get; set; }

		private TweetServiceBinder binder;

		public BindingTweetService()
			: base()
		{
			this.Tweets = new List<Tweet>();
			this.LastSinceId = 0;

			this.binder = new TweetServiceBinder(this);
		}

		public override IBinder OnBind(Intent intent)
		{
			base.OnBind(intent);

			return binder;
		}

		protected override void OnHandleIntent(Intent intent)
		{
			this.Tweets = Chapter11.Twitter.Search.SearchTweets(LastSinceId, "#MonoDroid");

			if (this.Tweets.Exists(t => t.Id > LastSinceId))
			{
				if (this.NewTweetsFound != null)
					this.NewTweetsFound();
			}
		}
		
		public class TweetServiceBinder : Binder
		{
			public TweetServiceBinder(BindingTweetService service)
			{
				this.ServiceInstance = service;
			}

			public BindingTweetService ServiceInstance
			{
				get;
				private set;
			}
		}

		public class TweetServiceConnection : Java.Lang.Object, IServiceConnection
		{
			public event Action<BindingTweetService> Connected;

			public event Action Disconnected;

			public void OnServiceConnected(ComponentName className, 
				IBinder	serviceBinder)
			{
				if (this.Connected != null)
					this.Connected((serviceBinder as TweetServiceBinder)
						.ServiceInstance);
			}

			public void OnServiceDisconnected(ComponentName className)
			{
				if (this.Disconnected != null)
					this.Disconnected();
			}
		}

		[Activity(Label = "CH11 Binding Service", MainLauncher=true,
			LaunchMode=Android.Content.PM.LaunchMode.SingleTask)]
		public class BindingActivity : Activity
		{
			TweetServiceConnection serviceConnection;

			protected override void OnCreate(Bundle bundle)
			{
				base.OnCreate(bundle);
				
				SetContentView(Resource.Layout.Main);

				Button button = FindViewById<Button>(Resource.Id.myButton);
				button.Text = "Check Tweets via Service";

				button.Click += delegate
				{
					StartService(new Intent(this, typeof(BindingTweetService)));
				};

				serviceConnection = new TweetServiceConnection();
				serviceConnection.Connected += (BindingTweetService svc) =>
				{
					Toast.MakeText(this, "Bound to Service!", 
						ToastLength.Short).Show();

					svc.NewTweetsFound += () =>
					{
						foreach (var tweet in svc.Tweets)
							Android.Util.Log.Info("CHAPTER-11", string.Format(
								"{0} - {1}: {2}", tweet.Id, tweet.FromUser, 
								tweet.Text));

						RunOnUiThread(() =>
						{
							Toast.MakeText(this, "Tweets Refreshed!", 
								ToastLength.Short).Show();
						});
					};
				};
			}

			protected override void OnResume()
			{
				base.OnResume();

				var serviceIntent = new Intent(this, typeof(BindingTweetService));
				BindService(serviceIntent, serviceConnection, Bind.AutoCreate);
			}

			protected override void OnPause()
			{
				UnbindService(serviceConnection);

				base.OnPause();
			}
		}
	}
}