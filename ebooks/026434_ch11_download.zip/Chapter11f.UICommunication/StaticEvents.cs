using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Chapter11.Twitter;

namespace Chapter11.UICommunication
{
	[Service]
	public class StaticEventService : IntentService
	{
		public static event Action<List<Tweet>> NewTweetsFound;

		public long LastSinceId { get; set; }

		public StaticEventService()
			: base()
		{
			this.LastSinceId = 0;
		}

		protected override void OnHandleIntent(Intent intent)
		{
			var lastSinceId = this.LastSinceId;

			var tweets = Search.SearchTweets(LastSinceId, "#MonoDroid");
			this.LastSinceId = tweets.Max(t => t.Id);

			var newTweets = from t in tweets
							where t.Id > lastSinceId
							select t;

			if (newTweets != null && newTweets.Count() > 0 && NewTweetsFound != null)
				NewTweetsFound(newTweets.ToList());
		}
	}

	[Activity(Label = "CH11 Static Events", MainLauncher=true,
		LaunchMode = Android.Content.PM.LaunchMode.SingleTask)]
	public class StaticEventActivity : Activity
	{
		Action<List<Tweet>> newTweetsAction;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			SetContentView(Resource.Layout.Main);

			var button = FindViewById<Button>(Resource.Id.myButton);
			button.Text = "Refresh Tweets";

			button.Click += delegate
			{
				StartService(new Intent(this, typeof(StaticEventService)));
			};

			newTweetsAction = (List<Tweet> tweets) => {
				foreach (var tweet in tweets)
					Android.Util.Log.Info("CHAPTER-11", string.Format(
					"{0} - {1}: {2}", tweet.Id, tweet.FromUser, tweet.Text));

				RunOnUiThread(() =>
				{
					Toast.MakeText(this, "Tweets Refreshed!", 
						ToastLength.Short).Show();
				});
			};	
		}

		protected override void OnResume()
		{
			base.OnResume();

			StaticEventService.NewTweetsFound += newTweetsAction;
		}

		protected override void OnPause()
		{
			StaticEventService.NewTweetsFound -= newTweetsAction;

			base.OnPause();
		}
	}
}