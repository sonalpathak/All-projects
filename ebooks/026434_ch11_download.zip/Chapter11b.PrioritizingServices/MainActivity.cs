﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Content.PM;

namespace Chapter11.PrioritizingServices
{
	[Activity(Label = "CH11 Prioritizing Services", MainLauncher = true,
		LaunchMode=Android.Content.PM.LaunchMode.SingleTask)]
	public class MainActivity : Activity
	{
		bool prioritized = false;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.Main);

			// Get our button from the layout resource,
			// and attach an event to it
			Button button = FindViewById<Button>(Resource.Id.myButton);
			button.Text = "Prioritize Service";

			button.Click += delegate 
			{
				prioritized = !prioritized;

				var intent = new Intent(this, typeof(PriorityService));
				intent.PutExtra("ShouldPrioritize", prioritized);

				StartService(intent);

				button.Text = prioritized ? "Deprioritize Service" : "Prioritize Service";
			};
		}
	}
}

