using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Chapter11.PrioritizingServices
{
	[Service]
	public class PriorityService : IntentService
	{
		bool isPrioritized = false;

		protected override void OnHandleIntent(Intent intent)
		{
			var shouldPrioritize = intent.GetBooleanExtra("ShouldPrioritize", false);

			Android.Util.Log.Info("CHAPTER-11", "PriorityService: " + shouldPrioritize);

			if (shouldPrioritize && !isPrioritized)
			{
				var notification = new Notification(
						Android.Resource.Drawable.SymActionEmail,
						"Prioritized Service!");
				notification.Flags = NotificationFlags.ForegroundService;
		
				var pendingIntent = PendingIntent.GetActivity(this, 0,
				  new Intent(this, typeof(MainActivity)),
				  PendingIntentFlags.UpdateCurrent);

				notification.SetLatestEventInfo(this, "Prioritized Service",
				  "Prioritized Service running", pendingIntent);

				StartForeground(1, notification);

				NotificationManager.FromContext(this).Notify(0, notification);
			}
			else if (!shouldPrioritize && isPrioritized)
			{
				StopForeground(true);
			}			
		}
	}
}