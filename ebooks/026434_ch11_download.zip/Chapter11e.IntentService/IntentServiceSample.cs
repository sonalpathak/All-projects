using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Chapter11.Twitter;

namespace Chapter11.IntentServiceSample
{
	[Service]
	public class IntentServiceSample : IntentService
	{
		List<Tweet> tweets = new List<Tweet>();
		Handler handler = new Handler();

		public override void OnCreate()
		{
			base.OnCreate();
		}

		protected override void OnHandleIntent(Intent intent)
		{			
			tweets = Search.SearchTweets(0, "#MonoDroid");
			foreach (var tweet in tweets)
				Android.Util.Log.Info("CHAPTER-11", string.Format(
					"{0} - {1}: {2}", tweet.Id, tweet.FromUser, tweet.Text));

			handler.Post(() =>
			{
				Toast.MakeText(this, "Tweets Refreshed!", ToastLength.Short).Show();
			});
		}
	}
}