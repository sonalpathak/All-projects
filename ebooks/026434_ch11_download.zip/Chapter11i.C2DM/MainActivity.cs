﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace Chapter11.C2DM
{
	[Activity(Label = "CH11 C2DM", MainLauncher = true)]
	public class MainActivity : Activity
	{
		bool registered = false;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			SetContentView(Resource.Layout.Main);

			Button button = FindViewById<Button>(Resource.Id.myButton);
			button.Text = "Register";

			button.Click += delegate 
			{
				registered = !registered;

				if (registered)
				{
					Intent registrationIntent = new Intent(
						"com.google.android.c2dm.intent.REGISTER");
					registrationIntent.PutExtra("app", 
						PendingIntent.GetBroadcast(this, 0, new Intent(), 0)); // boilerplate
					registrationIntent.PutExtra("sender", "email@ofsender.com");

					StartService(registrationIntent);
				}
				else
				{
					Intent unregIntent = new Intent(
						"com.google.android.c2dm.intent.UNREGISTER");
					unregIntent.PutExtra("app", 
						PendingIntent.GetBroadcast(this, 0, new Intent(), 0));
				
					StartService(unregIntent);
				}

				button.Text = registered ? "Unregister" : "Register";
			
			};
		}
	}
}

