using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Chapter11.C2DM
{
	[BroadcastReceiver(Permission = "com.google.android.c2dm.permission.SEND")]
	[IntentFilter(new string[] { "com.google.android.c2dm.intent.RECEIVE" },
		Categories = new string[] { "chapter11i.c2dm" })]
	[IntentFilter(new string[] { "com.google.android.c2dm.intent.REGISTRATION" },
		Categories = new string[] { "chapter11i.c2dm" })]
	public class C2DMBroadcastReceiver : BroadcastReceiver
	{
		public override void OnReceive(Context context, Intent intent)
		{
			var svcIntent = new Intent(context, typeof(C2DMService));

			svcIntent.PutExtras(intent.Extras);
			svcIntent.PutExtra("c2dm_action", intent.Action);

			context.StartService(svcIntent);
		}
	}

	[Service]
	public class C2DMService : IntentService
	{
		Handler handler;

		public override void OnCreate()
		{
			base.OnCreate();
			handler = new Handler();
		}

		protected override void OnHandleIntent(Intent intent)
		{			
			var action = intent.GetStringExtra("c2dm_action");

			if (action == "com.google.android.c2dm.intent.REGISTRATION")
			{
				var unregistered = intent.GetStringExtra("unregistered");
				var error = intent.GetStringExtra("error");

				if (!string.IsNullOrEmpty(error))
					Error(intent.Extras);
				else if (string.IsNullOrEmpty(unregistered))
					Registered(intent.GetStringExtra("registration_id"));
				else
					Unregistered();
						
			}
			else if (action == "com.google.android.c2dm.intent.RECEIVE")
			{
				Message(intent.Extras);
			}
		}

		void Registered(string registrationId)
		{
			//Send the registration id to your server...
			handler.Post(() => 
			{ 
				Toast.MakeText(this, "C2DM - Registered - " + registrationId,
					ToastLength.Short).Show(); 
			});
		}

		void Unregistered()
		{
			//Tell your server to stop sending messages to this device
			handler.Post(() => 
			{ 
				Toast.MakeText(this, "C2DM - Unregistered", 
					ToastLength.Short).Show(); 
			});
		}

		void Message(Bundle extras)
		{
			//Create a Notification to alert the user
			handler.Post(() => 
			{ 
				Toast.MakeText(this, "C2DM - Msg Received", 
					ToastLength.Short).Show(); 
			});
		}

		void Error(Bundle extras)
		{
			//Determine the error, and handle it
			handler.Post(() => 
			{ 
				Toast.MakeText(this, "C2DM - Error", 
					ToastLength.Short).Show(); 
			});
		}
	}
}