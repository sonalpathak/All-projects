﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Collections.Specialized;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;
using System.Dynamic;
using System.Collections;
using System.Collections.ObjectModel;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace C2DMTest
{
	class Program
	{
		static void Main(string[] args)
		{
			var authUrl = @"https://www.google.com/accounts/ClientLogin";
			var c2dmUrl = @"https://android.apis.google.com/c2dm/send";

			var googleSender = "sender@gmail.com";
			var googlePassword = "password";
			var registrationId = "registrationid";
			var message = "Hello from C2DM!";

			try
			{
				// First, let's get the auth code - requires Google credentials
				var sb = new StringBuilder();
				var kvp = new NameValueCollection();
				kvp.Add("accountType", "GOOGLE");
				kvp.Add("Email", googleSender);
				kvp.Add("Passwd", googlePassword);
				kvp.Add("service", "ac2dm");
				kvp.Add("source", "long2know.chapter11.c2dm");

				foreach (string key in kvp.Keys)
					sb.Append(string.Format("{0}={1}&", key, kvp[key]));
				
				var encoding = new ASCIIEncoding();
				byte[] data = encoding.GetBytes(sb.ToString());

				var myRequest = (HttpWebRequest)WebRequest.Create(authUrl);
				myRequest.Method = "POST";
				myRequest.ContentType = "application/x-www-form-urlencoded";
				myRequest.ContentLength = data.Length;
				Stream newStream = myRequest.GetRequestStream();
				newStream.Write(data, 0, data.Length);
				newStream.Close();

				var sr = new StreamReader(myRequest.GetResponse().GetResponseStream());
				string readResponse = sr.ReadToEnd();

				// Parse Auth
				Regex regAuth = new Regex(@"Auth=(.+)", RegexOptions.IgnoreCase);

				Match matchAuth = regAuth.Match(readResponse);

				string auth = string.Empty;

				if (matchAuth.Success)
					auth = matchAuth.Groups[0].Value;
				else
				{
					throw new WebException("Could not authenticate.", 
						new Exception("Failed to retrieve auth, sid, or lsid"));
				}

				// Igore SSL exceptions at this point
				ServicePointManager.ServerCertificateValidationCallback +=
					new RemoteCertificateValidationCallback((sender, cert, chain, policyErr) =>
					{
						return true;
					});

				// Finally, let's send the message
				sb = new StringBuilder();
				kvp = new NameValueCollection();
				kvp.Add("registration_id", HttpUtility.UrlEncode(registrationId));
				kvp.Add("delay_while_idle", "false");
				kvp.Add("collapse_key", "chapter11c2dm");
				kvp.Add("data.message", HttpUtility.UrlEncode(message));

				foreach (string key in kvp.Keys)
				{
					sb.Append(string.Format("{0}={1}&", key, kvp[key]));
				}

				data = encoding.GetBytes(sb.ToString());

				myRequest = (HttpWebRequest)WebRequest.Create(c2dmUrl);
				myRequest.Headers.Add(HttpRequestHeader.Authorization, 
					string.Format("GoogleLogin {0}", auth));
				myRequest.Method = "POST";
				myRequest.ContentType = "application/x-www-form-urlencoded";
				myRequest.ContentLength = data.Length;
				newStream = myRequest.GetRequestStream();
				newStream.Write(data, 0, data.Length);
				newStream.Close();

				sr = new StreamReader(myRequest.GetResponse().GetResponseStream());
				readResponse = sr.ReadToEnd();

				string id = string.Empty;
				Regex regId = new Regex(@"id=(.+)", RegexOptions.IgnoreCase);
				Match mactchId = regId.Match(readResponse);

				if (mactchId.Success)
				{
					id = matchAuth.Groups[0].Value;

					Console.WriteLine(string.Format("Received response: {0}", id));
				}
				else
				{
					Console.WriteLine(string.Format("Invalid response received: {0}", 
						readResponse));
				}

			}
			catch (WebException e)
			{
				Console.WriteLine(string.Format("Web Exception: {0}", e.InnerException));
			}
		}
	}
}
