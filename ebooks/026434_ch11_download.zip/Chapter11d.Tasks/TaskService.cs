using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Chapter11.Twitter;

namespace Chapter11.Tasks
{
	[Service]
	public class TaskService : Service
	{
		List<Tweet> tweets = new List<Tweet>();
		Handler handler = new Handler();

		public override IBinder OnBind(Intent intent)
		{
			return default(IBinder);
		}

		public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
		{
			var result = base.OnStartCommand(intent, flags, startId);

			Task.Factory.StartNew(() =>
			{
				tweets = Search.SearchTweets(0, "#MonoDroid");
				
				Parallel.ForEach<Tweet>(tweets, (Tweet tweet) =>
				{
					Android.Util.Log.Info("CHAPTER-11", string.Format(
						"{0} - {1}: {2}", tweet.Id, tweet.FromUser, tweet.Text));
				});

				handler.Post(() =>
				{
					Toast.MakeText(this, "Tweets Refreshed!", 
						ToastLength.Short).Show();
				});
			});

			return result;
		}
	}
}