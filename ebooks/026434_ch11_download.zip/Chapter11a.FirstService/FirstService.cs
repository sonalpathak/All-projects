using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Chapter11.FirstService
{
	[Service]
	public class FirstService : Service
	{
		List<Twitter.Tweet> tweets = new List<Twitter.Tweet>();

		public override IBinder OnBind(Intent intent)
		{
			throw new NotImplementedException();
		}

		public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
		{
			var startCmdResult = base.OnStartCommand(intent, flags, startId);
			
			tweets = Twitter.Search.SearchTweets(0, "#MonoDroid");

			foreach (var tweet in tweets)
				Android.Util.Log.Info("CHAPTER-11",
					string.Format("{0} - {1}: {2}", tweet.Id,
					tweet.FromUser, tweet.Text));

			Toast.MakeText(this, "Tweets Refreshed!", ToastLength.Short).Show();

			return startCmdResult;
		}
	}
}