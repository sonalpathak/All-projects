﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace Chapter11.FirstService
{
	[Activity(Label = "CH11 First Service", MainLauncher = true)]
	public class MainActivity : Activity
	{
		bool started = false;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			SetContentView(Resource.Layout.Main);

			Button button = FindViewById<Button>(Resource.Id.myButton);
			button.Text = "Start Service";

			button.Click += delegate 
			{
				started = !started;

				if (started)
					StartService(new Intent(this, typeof(FirstService)));
				else
					StopService(new Intent(this, typeof(FirstService)));

				button.Text = started ? "Stop Service" : "Start Service";
			};			
		}
	}
}

