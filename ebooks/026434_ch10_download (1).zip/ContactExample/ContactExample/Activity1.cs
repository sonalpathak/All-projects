using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Util;
using Android.Provider;

namespace ContactExample
{
	[Activity (Label = "Contact Examples", MainLauncher = true)]
	public class Activity1 : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);
			
			var contactListLogButton = FindViewById<Button>(Resource.Id.contactListLogButton);
            contactListLogButton.Click += (s, e) =>
            {
				var uri = ContactsContract.Contacts.ContentUri;
				var cursor = ManagedQuery(uri, null, null, null, null);
				if(cursor.Count > 0)
				{
				   while(cursor.MoveToNext())
				   {
				      Log.Info("Mono for Android", "Id = {0}", cursor.GetString(cursor.GetColumnIndex(BaseColumns.Id)));
				      Log.Info("Mono for Android", "Name = {0}",cursor.GetString(cursor.GetColumnIndex(ContactsContract.ContactsColumns.DisplayName)));
				      Log.Info("Mono for Android", "==============");
				   }
				   cursor.Close();
				}
            };
			
			var phoneAndEmailContentButton = FindViewById<Button>(Resource.Id.phoneAndEmailContentButton);
			phoneAndEmailContentButton.Click += (s, e) =>
			{
				var uri = ContactsContract.Contacts.ContentUri;
				var cursor = ManagedQuery(uri, null, null, null, null);
				if(cursor.Count > 0)
				{
					while(cursor.MoveToNext())
					{
						var contactId = cursor.GetString(cursor.GetColumnIndex(BaseColumns.Id));
						Log.Info("Mono for Android", "Id = {0}", contactId);
						Log.Info("Mono for Android", "Name = {0}", cursor.GetString(cursor.GetColumnIndex(ContactsContract.ContactsColumns.DisplayName)));
						if(cursor.GetInt(cursor.GetColumnIndex(ContactsContract.ContactsColumns.HasPhoneNumber)) == 1)
						{
							var phoneCursor = ManagedQuery(ContactsContract.CommonDataKinds.Phone.ContentUri, null, "CONTACT_ID" + " = " + contactId, null, null);
							while(phoneCursor.MoveToNext())
							{
								var number =  phoneCursor.GetString(phoneCursor.GetColumnIndex(ContactsContract.CommonDataKinds.Phone.Number));
								var type = (PhoneDataKind) phoneCursor.GetInt(phoneCursor.GetColumnIndex("DATA2"));
								
								Log.Info("Mono for Android", "Telephone: {0} - {1}", number, type.ToString());
							}
							phoneCursor.Close();
						}
						
						var emailCursor = ManagedQuery(ContactsContract.CommonDataKinds.Email.ContentUri, null, "CONTACT_ID" + " = " + contactId, null, null);
						while(emailCursor.MoveToNext())
						{
							var email =  emailCursor.GetString(emailCursor.GetColumnIndex("DATA1"));
							
							Log.Info("Mono for Android", "E-mail: {0}", email);
						}
						emailCursor.Close();
						Log.Info("Mono for Android", "==============");
					}
					cursor.Close();
				}
				else
				{
					Toast.MakeText(this, "No contacts found", ToastLength.Long).Show();	
				}
			};
			
			var howManyFredsButton = FindViewById<Button>(Resource.Id.howManyFredsButton);
            howManyFredsButton.Click += (s, e) =>
            {
				var filterUri = ContactsContract.Contacts.ContentFilterUri;
				var uri = Android.Net.Uri.WithAppendedPath(filterUri, "Fred");
				
				var cursor = ManagedQuery(uri, null, null, null, null);
				Toast.MakeText(this, "Found " + cursor.Count + " people with Fred in their name", ToastLength.Long).Show();		
			};
			
			var contactDetailButton = FindViewById<Button>(Resource.Id.contactDetailButton);
            contactDetailButton.Click += (s, e) =>
            {
                // Display contact detail for ID 1
                var contactUri = ContactsContract.Contacts.ContentUri;
                var uri = Android.Net.Uri.WithAppendedPath(contactUri, "1");

                var intent = new Intent(Intent.ActionView, uri);
                StartActivity(intent);
            };

            var contactPickerButton = FindViewById<Button>(Resource.Id.contactPickerButton);
            contactPickerButton.Click += (s, e) =>
            {
                // Display contact picker
                var intent = new Intent(Intent.ActionPick, ContactsContract.Contacts.ContentUri);
                StartActivityForResult(intent, 100);
            };

            var contactInsertButton = FindViewById<Button>(Resource.Id.contactInsertButton);
            contactInsertButton.Click += (s, e) =>
            {
                // Insert a new contact
				var intent = new Intent(Intent.ActionInsert, ContactsContract.Contacts.ContentUri);
				
				intent.PutExtra(ContactsContract.Intents.Insert.Name, "Chris Hardy");
				intent.PutExtra(ContactsContract.Intents.Insert.Phone, "1-408-867-5309");
				intent.PutExtra(ContactsContract.Intents.Insert.Email, "chrisntr@gmail.com");
				
				this.StartActivityForResult(intent, 150);
            };

            var contactInsertEditButton = FindViewById<Button>(Resource.Id.contactInsertEditButton);
            contactInsertEditButton.Click += (s, e) =>
            {
                var intent = new Intent(Intent.ActionInsertOrEdit);
                intent.SetType(ContactsContract.Contacts.ContentItemType);

                intent.PutExtra(ContactsContract.Intents.Insert.Name, "Chris Hardy");
                intent.PutExtra(ContactsContract.Intents.Insert.Phone, "1-408-867-5309");
                intent.PutExtra(ContactsContract.Intents.Insert.Email, "chrisntr@gmail.com");

                this.StartActivityForResult(intent, 150);
            };
		}
		
		protected override void OnActivityResult (int requestCode, Result resultCode, Intent data)
		{
            // Request 150 comes from inserting or editing a new contact
            if(requestCode == 150)
            {
                if (resultCode == Result.Ok)
                {
                    // TODO: Handle successful contact being added.
                    Log.Info("Mono for Android", "Ok");
                }
                else if (resultCode == Result.Canceled)
                {
                    // TODO: Handle no new contact getting added.
                    Log.Info("Mono for Anroid", "Canceled");
                }    
            }

            // Request 100 comes from contact picker
			if(requestCode == 100)
			{
				if (data != null)
				{
					var cursor = ManagedQuery(data.Data, null, null, null, null);
					if(cursor.Count > 0)
					{
						cursor.MoveToFirst();
						Toast.MakeText(this, "Got contact " + cursor.GetString(cursor.GetColumnIndex(ContactsContract.ContactsColumns.DisplayName)), ToastLength.Long).Show();		
					}	
				}
				else
				{
					Toast.MakeText(this, "No contact picked", ToastLength.Long).Show();
				}
			}
		}
	}
}


