package mapsexample.mapsexample;

import android.os.Bundle;

public class CustomMapActivity extends com.google.android.maps.MapActivity {
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
    }

    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }
}
