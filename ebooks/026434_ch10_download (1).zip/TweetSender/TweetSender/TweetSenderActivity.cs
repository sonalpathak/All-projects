using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace TweetSender
{
	[Activity (Label = "Tweet Sender", MainLauncher = true)]
	public class TweetSenderActivity : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);
			
			// This application sends intents to both Twidroyd and the 
			// custom TweetReceiver application that is created
			
			var hootButton = FindViewById<Button>(Resource.Id.hootButton);
			
			hootButton.Click += delegate {
				var intent = new Intent(Intent.ActionSend);
				intent.PutExtra(Intent.ExtraText, "Sending a tweet to another application");
				intent.SetType("application/twitter");
				StartActivity(Intent.CreateChooser(intent, "Select Twitter application"));
			};
			
			var customTwitterAppButton = FindViewById<Button>(Resource.Id.customTwitterAppButton);
			
			customTwitterAppButton.Click += delegate {
				var intent = new Intent(Intent.ActionSend);
				intent.PutExtra(Intent.ExtraText, "Sending a tweet to another application");
				StartActivity(Intent.CreateChooser(intent, "Select Twitter application"));
			};

		}
	}
}


