using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace TweetReceiver
{
	[IntentFilter (new[]{Intent.ActionSend}, Categories=new[]{Intent.CategoryDefault})]
	[Activity (Label = "Tweet Receiver", MainLauncher = true)]
	public class TweetReceiverActivity : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			var action = this.Intent.Action;
			if(Intent.ActionSend == action)
			{
			   //We have text for a tweet.
			   var sentText = this.Intent.Extras.GetString(Intent.ExtraText);
			   Toast.MakeText(this, sentText, ToastLength.Long).Show();
			}

		}
	}
}


