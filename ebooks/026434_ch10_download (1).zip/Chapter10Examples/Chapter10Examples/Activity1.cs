using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Telephony;

namespace Chapter10Examples
{
	[BroadcastReceiver]
	public class SentSms : BroadcastReceiver
	{
		public override void OnReceive (Context context, Intent intent)
		{
			if(this.ResultCode == (int) Result.Ok)
			{
				Android.Util.Log.Debug("Mono for Android","Result OK");	
			}
			else if (this.ResultCode == (int) SmsResultError.GenericFailure)
			{
                Android.Util.Log.Debug("Mono for Android", "Generic Failure");		
			}
			else if (this.ResultCode == (int) SmsResultError.NoService)
			{
                Android.Util.Log.Debug("Mono for Android", "No Service");		
			}
			else if (this.ResultCode == (int) SmsResultError.NullPdu)
			{
                Android.Util.Log.Debug("Mono for Android", "Null Pdu");		
			}
			else if (this.ResultCode == (int) SmsResultError.RadioOff)
			{
                Android.Util.Log.Debug("Mono for Android", "Radio Off");		
			}	
		}
	}
	
	[Activity(Label = "Chapter 10 Examples", MainLauncher = true)]
	public class Activity1 : Activity
	{

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			
			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);
			
			// Get our button from the layout resource,
			// and attach an event to it
			var browserButton = FindViewById<Button> (Resource.Id.browserButton);
            browserButton.Click += (s, e) =>
            {
				// Opening up the browser
				var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://wrox.com"));
				StartActivity(intent);
            };

            var webViewAppButton = FindViewById<Button> (Resource.Id.webViewAppButton);
            webViewAppButton.Click += (s, e) =>
            {
				// Opening up the browser activity
				var intent = new Intent(this, typeof(WebActivity));
				StartActivity(intent);
            };

            var emailButton = FindViewById<Button>(Resource.Id.emailButton);
            emailButton.Click += (s, e) =>
            {
				// Opening up e-mail
				var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("mailto:chris@example.com?cc=other@example.com&subject=Wrox&body=MonoDroid "));
				StartActivity(intent);
            };

            var telDialButton = FindViewById<Button>(Resource.Id.telDialButton);
            telDialButton.Click += (s, e) =>
            {
				// Dial a number
				var intent = new Intent(Intent.ActionDial, Android.Net.Uri.Parse("tel:1-408-867-5309"));
				StartActivity(intent);
            };

            var telCallButton = FindViewById<Button>(Resource.Id.telCallButton);
            telCallButton.Click += (s, e) =>
            {
				// Call a number
				var intent = new Intent(Intent.ActionCall, Android.Net.Uri.Parse("tel:1-408-867-5309"));
				StartActivity(intent);
            };


            Button smsButton = FindViewById<Button>(Resource.Id.smsButton);
            smsButton.Click += (s, e) =>
            {
				var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("sms:1-408-867-5309"));
				StartActivity(intent);
            };

            Button smsWithBodyButton = FindViewById<Button>(Resource.Id.smsWithBodyButton);
            smsWithBodyButton.Click += (s, e) =>
            {
                var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("sms:1-408-867-5309"));
                intent.PutExtra("sms_body", "Message Body");
                StartActivity(intent);
            };

            var smsProgramaticallyButton = FindViewById<Button>(Resource.Id.smsProgramaticallyButton);
            smsProgramaticallyButton.Click += (s, e) =>
            {
                // Send SMS Programatically
                PendingIntent sentPendingIntent = PendingIntent.GetBroadcast(this, 200, new Intent(this, typeof(SentSms)), 0);
                var smsManager = SmsManager.Default;
                smsManager.SendTextMessage("ATelephoneNumber", null, "This is a automated SMS", sentPendingIntent, null);
            };

		    var mapsButton = FindViewById<Button>(Resource.Id.mapsButton);
            mapsButton.Click += (s, e) =>
            {
				// Display maps.
				var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://maps.google.com/maps?q=Manchester,UK"));
				StartActivity(intent);
            };

            var youtubeButton = FindViewById<Button>(Resource.Id.youtubeButton);
            youtubeButton.Click += (s, e) =>
            {
                // Play youtube video.
				var videoId = "QHy0nBYwIKM";
				var youTubeUrl = String.Format("http://youtube.com/watch?v={0}", videoId);
				var url = Android.Net.Uri.Parse(youTubeUrl);
				var intent = new Intent(Intent.ActionView, url);
				StartActivity(intent);
            };

            var marketplaceSearchButton = FindViewById<Button>(Resource.Id.marketplaceSearchButton);
            marketplaceSearchButton.Click += (s, e) =>
            {
                // Search Android Marketplace
                var searchTerm = "Google";
                var url = Android.Net.Uri.Parse(String.Format("market://search?q={0}", searchTerm));
                var intent = new Intent(Intent.ActionView, url);
                StartActivity(intent);
            };

            var marketplaceSearch2Button = FindViewById<Button>(Resource.Id.marketplaceSearch2Button);
            marketplaceSearch2Button.Click += (s, e) =>
            {
                //Search Android Marketplace
                var publisher = "Google Inc.";
                var url = Android.Net.Uri.Parse(String.Format("market://search?q=pub:{0}", publisher));
                var intent = new Intent(Intent.ActionView, url);
                StartActivity(intent);
            };

            var marketplaceSearch3Button = FindViewById<Button>(Resource.Id.marketplaceSearch3Button);
            marketplaceSearch3Button.Click += (s, e) =>
            {
                // Search Android Marketplace
                var packageName = "com.google.earth";
                var url = Android.Net.Uri.Parse(String.Format("market://search?q=pname:{0}", packageName));
                var intent = new Intent(Intent.ActionView, url);
                StartActivity(intent);
            };

            var marketplaceAppButton = FindViewById<Button>(Resource.Id.marketplaceAppButton);
            marketplaceAppButton.Click += (s, e) =>
            {
                // Go direct to an Marketplace app
                var packageName = "com.google.earth";
                var url = Android.Net.Uri.Parse(String.Format("market://details?id={0}", packageName));
                var intent = new Intent(Intent.ActionView, url);
                StartActivity(intent);
            };
				
				// Display maps 2.
//				var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("geo:0,0?z=3"));
//				StartActivity(intent);                        
//				// Crashes on Emulator, no real device to try it on...
			
				
//				// Display contact detail from lookup id
//				var contactUri = ContactsContract.Contacts.ContentLookupUri;
//				var uri = Android.Net.Uri.WithAppendedPath(contactUri, "681i202/66");
//				var intent = new Intent(Intent.ActionView, uri);
//				StartActivity(intent);
		}
	}
}


