using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.Drawing;
using System;

namespace Lab2.GCAndMe
{
	[Register ("GCAndMeViewController")]
	partial class GCAndMeViewController : UIViewController
	{
		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			View.BackgroundColor = UIColor.White;

			// The image we will work with; we derive our own so we can see
			// it get destroyed.
			var imageView = new MyImageView();
			Add(imageView);
			PositionImage (imageView);

			WeakReference wr = new WeakReference(imageView);
			imageView = null; // set it to null so we aren't holding it anymore.

			// Create the button to remove our image
			AddButton(40, "Remove Image from Screen", 
				(sender, e) => {
					Console.WriteLine ("Removing image from UI");

					var iv = wr.Target as UIImageView;
					if (iv != null) {
						iv.RemoveFromSuperview();
						iv.Dispose(); // best practice to dispose when not used anymore
					}
				});

			// TODO: Step 1 - Force GC
			AddButton(80, "Force GC Now!", 
				(sender, e) => {
					// This forces a Garbage Collection
					Console.WriteLine ("Forcing GC!");
					GC.Collect();
					GC.WaitForPendingFinalizers();
					GC.Collect();
				});

			// TODO: Step 4 - Remove the reference
			AddButton(120, "Set ImageView reference to null", 
				(sender, e) => {
					Console.WriteLine ("Setting reference to null.");
					imageView = null;
				});
		}

		#region Support methods
		UIButton AddButton(float yPos, string text, EventHandler clicked) 
		{
			var button = new UIButton(UIButtonType.System) {
				Frame = new RectangleF(0, yPos, View.Bounds.Width, 30),
			};
			button.SetTitle(text, UIControlState.Normal);
			button.TouchUpInside += clicked;
			Add(button);

			return button;
		}

		void PositionImage (MyImageView imgView)
		{
			if (imgView == null)
				return;

			imgView.TranslatesAutoresizingMaskIntoConstraints = false;
			this.View.AddConstraint(NSLayoutConstraint.Create(this.View,
				NSLayoutAttribute.Bottom, NSLayoutRelation.Equal,
				imgView, 
				NSLayoutAttribute.Bottom, 1, 40));

			this.View.AddConstraint(NSLayoutConstraint.Create(this.View,
				NSLayoutAttribute.CenterX, NSLayoutRelation.Equal,
				imgView, 
				NSLayoutAttribute.CenterX, 1, 0));
		}
		#endregion
	}
}
