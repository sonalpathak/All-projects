﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace HamburgerMenuExample {
	public partial class HomePage : ContentPage {
		public HomePage() {
			InitializeComponent();
		}
	}
}

