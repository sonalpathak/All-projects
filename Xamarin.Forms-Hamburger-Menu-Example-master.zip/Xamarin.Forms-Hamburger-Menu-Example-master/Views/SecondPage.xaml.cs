﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace HamburgerMenuExample {
	public partial class SecondPage : ContentPage {
		public SecondPage() {
			InitializeComponent();
		}
	}
}

