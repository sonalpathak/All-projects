namespace Stryker.Fims {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schemas.stryker.com/fims/2012-03/fimsitemmsg",@"FIMSItemMsg")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FIMSItemMsg"})]
    public sealed class FIMSItemMsg : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schemas.stryker.com/fims/2012-03/fimsitemmsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://schemas.stryker.com/fims/2012-03/fimsitemmsg"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo root_reference=""FIMSItemMsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FIMSItemMsg"">
    <xs:annotation>
      <xs:appinfo>
        <recordInfo rootTypeName=""FIMSItemMsg"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element ref=""Source"" />
        <xs:element minOccurs=""0"" ref=""Transmit"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""Item"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""Source"">
    <xs:complexType>
      <xs:attribute name=""name"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Transmit"">
    <xs:complexType>
      <xs:attribute name=""timestamp"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:dateTime"" />
        </xs:simpleType>
      </xs:attribute>
      <xs:attribute name=""by"" type=""xs:string"" use=""optional"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Item"">
    <xs:annotation>
      <xs:documentation>A material, component or product listed in inventory</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""ItemId"">
          <xs:annotation>
            <xs:documentation>The item code or unique descriptor</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""ExUid"" nillable=""true"" type=""xs:integer"">
          <xs:annotation>
            <xs:documentation>The unique numeric ID of the item</xs:documentation>
          </xs:annotation>
        </xs:element>
        <xs:element name=""Description"">
          <xs:annotation>
            <xs:documentation>The short description for the item</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""255"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Status"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""PackageQty"">
          <xs:simpleType>
            <xs:restriction base=""xs:integer"">
              <xs:minInclusive value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""IssueUnit"">
          <xs:annotation>
            <xs:documentation>Units of measure for issuing the item</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Type"">
          <xs:annotation>
            <xs:documentation>System-defined item type</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""SerialControl"" nillable=""true"" type=""xs:integer"">
          <xs:annotation>
            <xs:documentation>Serial number control code (1=No control; 2=Predefined numbers; 5=Dynamic entry at receipt; 6=Dynamic entry at sales order issue</xs:documentation>
          </xs:annotation>
        </xs:element>
        <xs:element minOccurs=""0"" name=""LotControl"" nillable=""true"" type=""xs:integer"">
          <xs:annotation>
            <xs:documentation>Lot control code (1=No control; 2=Full control)</xs:documentation>
          </xs:annotation>
        </xs:element>
        <xs:element minOccurs=""0"" name=""ListPrice"" nillable=""true"">
          <xs:annotation>
            <xs:documentation>List sales price for the item</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:list itemType=""xs:decimal"" />
          </xs:simpleType>
        </xs:element>
        <xs:element name=""UpdatedTs"">
          <xs:annotation>
            <xs:documentation>The date/time the master item was updated</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ProductLine"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Brand"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""SubBrand"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Segment"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""LRFlag"">
          <xs:annotation>
            <xs:documentation>Limited Release Flag (Y = True, NULL or N = False)</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""1"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FIMSItemMsg() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FIMSItemMsg";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
