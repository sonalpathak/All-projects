namespace Stryker.Fims {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schemas.stryker.com/fims/2012-03/fimsordermsg",@"FIMSOrderMsg")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FIMSOrderMsg"})]
    public sealed class FIMSOrderMsg : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schemas.stryker.com/fims/2012-03/fimsordermsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://schemas.stryker.com/fims/2012-03/fimsordermsg"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <schemaInfo root_reference=""FIMSOrderMsg"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FIMSOrderMsg"">
    <xs:complexType>
      <xs:sequence>
        <xs:element ref=""Source"" />
        <xs:element minOccurs=""0"" ref=""Transmit"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""FIMSOrder"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""FIMSOrderLine"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""Source"">
    <xs:complexType>
      <xs:attribute name=""name"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Transmit"">
    <xs:complexType>
      <xs:attribute name=""timestamp"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:dateTime"" />
        </xs:simpleType>
      </xs:attribute>
      <xs:attribute name=""by"" type=""xs:string"" use=""optional"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""FIMSOrder"">
    <xs:annotation>
      <xs:documentation>FIMS-generated document initiating the sale, sample, or replenishment of products</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""FIMSOrderId"">
          <xs:annotation>
            <xs:documentation>The unique key which identifies the order within FIMS</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""OrderType"">
          <xs:annotation>
            <xs:documentation>System-defined order type</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""RequestTs"">
          <xs:annotation>
            <xs:documentation>The date/time the order was created</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
        <xs:element name=""CustomerId"">
          <xs:annotation>
            <xs:documentation>The customer that is ordering the product</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ShipToLocationId"">
          <xs:annotation>
            <xs:documentation>The customer's ship-to location/address number</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""CustomerPO"">
          <xs:annotation>
            <xs:documentation>Customer's purchase order</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""SalesRepId"">
          <xs:annotation>
            <xs:documentation>Unique identifier for the sales rep that is placing the order</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ToSalesRepId"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Notes"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""512"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ShippingMethod"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ShippingNotes"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""512"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
  <xs:element name=""FIMSOrderLine"">
    <xs:annotation>
      <xs:documentation>Individual line item within a FIMS Order</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""FIMSOrderId"">
          <xs:annotation>
            <xs:documentation>The unique key which identifies the overall order within FIMS</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""FIMSLineId"">
          <xs:annotation>
            <xs:documentation>Line sequence number within the order</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""LineType"" type=""xs:string"" />
        <xs:element name=""ItemId"">
          <xs:annotation>
            <xs:documentation>The item code or unique descriptor</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""LotNumber"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""OrderedQuantity"">
          <xs:simpleType>
            <xs:restriction base=""xs:integer"">
              <xs:minInclusive value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ReasonCode"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FIMSOrderMsg() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FIMSOrderMsg";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
