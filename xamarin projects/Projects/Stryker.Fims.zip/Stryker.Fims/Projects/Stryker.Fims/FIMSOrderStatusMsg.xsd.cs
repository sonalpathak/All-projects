namespace Stryker.Fims {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schemas.stryker.com/fims/2012-03/fimsorderstatusmsg",@"FIMSOrderStatusMsg")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FIMSOrderStatusMsg"})]
    public sealed class FIMSOrderStatusMsg : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schemas.stryker.com/fims/2012-03/fimsorderstatusmsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://schemas.stryker.com/fims/2012-03/fimsorderstatusmsg"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <schemaInfo root_reference=""FIMSOrderStatusMsg"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FIMSOrderStatusMsg"">
    <xs:complexType>
      <xs:sequence>
        <xs:element ref=""Source"" />
        <xs:element minOccurs=""0"" ref=""Transmit"" />
        <xs:element minOccurs=""0"" maxOccurs=""1"" ref=""FIMSOrderStatus"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""FIMSOrderLineStatus"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""Source"">
    <xs:complexType>
      <xs:attribute name=""name"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Transmit"">
    <xs:complexType>
      <xs:attribute name=""timestamp"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:dateTime"" />
        </xs:simpleType>
      </xs:attribute>
      <xs:attribute name=""by"" type=""xs:string"" use=""optional"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""FIMSOrderStatus"">
    <xs:annotation>
      <xs:documentation>Updates to sales orders, both at the Header and Line level</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""OrderId"">
          <xs:annotation>
            <xs:documentation>Oracle Order Number</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""FIMSOrderId"">
          <xs:annotation>
            <xs:documentation>The unique key which identifies the order within FIMS</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""OrderedTs"">
          <xs:annotation>
            <xs:documentation>Date Ordered</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
        <xs:element name=""CustomerPO"">
          <xs:annotation>
            <xs:documentation>Customer's purchase order</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""ShipToLocationId"">
          <xs:annotation>
            <xs:documentation>The customer's ship-to location/address number</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""OrderStatus"">
          <xs:annotation>
            <xs:documentation>Order Header Status</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""OrderFlowStatus"" type=""xs:string"" />
        <xs:element name=""OrderHoldName"" type=""xs:string"" />
        <xs:element name=""Notes"" type=""xs:string"" />
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
  <xs:element name=""FIMSOrderLineStatus"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""LineId"">
          <xs:annotation>
            <xs:documentation>Oracle Line Number</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""FIMSLineId"">
          <xs:annotation>
            <xs:documentation>FIMS-specific line sequence number within the order</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ItemId"">
          <xs:annotation>
            <xs:documentation>Ordered Item</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""OrderedQuantity"">
          <xs:simpleType>
            <xs:restriction base=""xs:integer"">
              <xs:minInclusive value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""FulfilledQuantity"">
          <xs:simpleType>
            <xs:restriction base=""xs:integer"">
              <xs:minInclusive value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""RequestTs"">
          <xs:annotation>
            <xs:documentation>The date/time the order was created</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""LineStatus"">
          <xs:annotation>
            <xs:documentation>Order Line Status</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""TrackingNumber"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""ShipmentTs"">
          <xs:annotation>
            <xs:documentation>Shipment Date</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
        <xs:element name=""LineHoldName"" type=""xs:string"" />
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FIMSOrderStatusMsg() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FIMSOrderStatusMsg";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
