namespace Stryker.Fims {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schemas.stryker.com/fims/2012-03/fimscustomermsg",@"FIMSCustomerMsg")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FIMSCustomerMsg"})]
    public sealed class FIMSCustomerMsg : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schemas.stryker.com/fims/2012-03/fimscustomermsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://schemas.stryker.com/fims/2012-03/fimscustomermsg"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo root_reference=""FIMSCustomerMsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FIMSCustomerMsg"">
    <xs:complexType>
      <xs:sequence>
        <xs:element ref=""Source"" />
        <xs:element minOccurs=""0"" ref=""Transmit"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""Customer"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""Site"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""Source"">
    <xs:complexType>
      <xs:attribute name=""name"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Transmit"">
    <xs:complexType>
      <xs:attribute name=""timestamp"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:dateTime"" />
        </xs:simpleType>
      </xs:attribute>
      <xs:attribute name=""by"" type=""xs:string"" use=""optional"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Customer"">
    <xs:annotation>
      <xs:documentation>An organization that buys products or services from the business</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerId"">
          <xs:annotation>
            <xs:documentation>The customer number or unique descriptor</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Name"">
          <xs:annotation>
            <xs:documentation>The description by which the customer is known</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Type"">
          <xs:annotation>
            <xs:documentation>System-defined customer type</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ActiveStatus"" type=""xs:string"" />
        <xs:element name=""Territory"">
          <xs:annotation>
            <xs:documentation>The unique identifier for the territory that the customer belongs to</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""ShipToLocationId"">
          <xs:annotation>
            <xs:documentation>The primary ship-to location for the customer</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""BillToLocationId"">
          <xs:annotation>
            <xs:documentation>The primary bill-to location for the customer</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""UpdatedTs"">
          <xs:annotation>
            <xs:documentation>The date/time the customer information was updated</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
  <xs:element name=""Site"">
    <xs:annotation>
      <xs:documentation>The details of the place where a customer is located or conducts business</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerId"">
          <xs:annotation>
            <xs:documentation>The unique customer number that the site belongs to</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ActiveStatus"" type=""xs:string"" />
        <xs:element name=""Primary"" type=""xs:boolean"" />
        <xs:element name=""LocationId"">
          <xs:annotation>
            <xs:documentation>The physical location or address associated with the site</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""SiteId"">
          <xs:annotation>
            <xs:documentation>The site number or unique descriptor</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Purpose"">
          <xs:annotation>
            <xs:documentation>Business purpose assigned to the site, such as Ship-To or Bill-To</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Line1"">
          <xs:annotation>
            <xs:documentation>Line 1 of the address</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""Line2"">
          <xs:annotation>
            <xs:documentation>Line 2 of the address</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Line3"">
          <xs:annotation>
            <xs:documentation>Line 3 of the address</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""City"">
          <xs:annotation>
            <xs:documentation>City or town of the address</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""State"">
          <xs:annotation>
            <xs:documentation>State or Province of the address</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""PostalCode"">
          <xs:annotation>
            <xs:documentation>A code of letters or digits used to locate the address</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element minOccurs=""0"" name=""Country"">
          <xs:annotation>
            <xs:documentation>Nation where the address is located (e.g., ""US"")</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""UpdatedTs"">
          <xs:annotation>
            <xs:documentation>The date/time the address information was updated</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
      </xs:sequence>
      <xs:attribute name=""action"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:enumeration value=""Create"" />
            <xs:enumeration value=""Update"" />
            <xs:enumeration value=""Delete"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:attribute>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FIMSCustomerMsg() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FIMSCustomerMsg";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
