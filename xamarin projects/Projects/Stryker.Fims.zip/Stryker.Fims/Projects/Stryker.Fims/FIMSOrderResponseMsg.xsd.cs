namespace Stryker.Fims {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schemas.stryker.com/fims/2012-03/fimsorderresponsemsg",@"FIMSOrderResponseMsg")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FIMSOrderResponseMsg"})]
    public sealed class FIMSOrderResponseMsg : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://schemas.stryker.com/fims/2012-03/fimsorderresponsemsg"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://schemas.stryker.com/fims/2012-03/fimsorderresponsemsg"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <schemaInfo root_reference=""FIMSOrderResponseMsg"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FIMSOrderResponseMsg"">
    <xs:complexType>
      <xs:sequence>
        <xs:element ref=""Source"" />
        <xs:element minOccurs=""0"" ref=""Transmit"" />
        <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""FIMSOrderResponse"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""Source"">
    <xs:complexType>
      <xs:attribute name=""name"" type=""xs:string"" use=""required"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""Transmit"">
    <xs:complexType>
      <xs:attribute name=""timestamp"" use=""required"">
        <xs:simpleType>
          <xs:restriction base=""xs:dateTime"" />
        </xs:simpleType>
      </xs:attribute>
      <xs:attribute name=""by"" type=""xs:string"" use=""optional"" />
    </xs:complexType>
  </xs:element>
  <xs:element name=""FIMSOrderResponse"">
    <xs:annotation>
      <xs:documentation>Response to FIMSOrderMsg messages submitted by FIMS</xs:documentation>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""FIMSOrderId"">
          <xs:annotation>
            <xs:documentation>The unique key which identifies the order within FIMS</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""64"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""FIMSLineId"">
          <xs:annotation>
            <xs:documentation>FIMS-specific line sequence number within the order</xs:documentation>
          </xs:annotation>
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ResponseCode"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""32"" />
              <xs:minLength value=""1"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ResponseMessage"">
          <xs:simpleType>
            <xs:restriction base=""xs:string"">
              <xs:maxLength value=""512"" />
              <xs:minLength value=""0"" />
            </xs:restriction>
          </xs:simpleType>
        </xs:element>
        <xs:element name=""ResponseTs"">
          <xs:simpleType>
            <xs:restriction base=""xs:dateTime"" />
          </xs:simpleType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FIMSOrderResponseMsg() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FIMSOrderResponseMsg";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
