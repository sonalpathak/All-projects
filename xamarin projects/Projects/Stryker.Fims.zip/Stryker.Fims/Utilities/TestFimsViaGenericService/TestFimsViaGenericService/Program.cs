﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using System.IO;
using System.Configuration;

namespace TestTwoWay
{
    class Program
    {
        [ServiceContract()]
        private interface IBizTalkSubmission
        {
            [OperationContract(Action = "BizTalkSubmit1", ReplyAction = "*")]
            void Submit(System.ServiceModel.Channels.Message msg);
        }

        static void Main(string[] args)
        {
            bool exitLoop = false;
            while (!exitLoop)
            {
                try
                {
                    Console.WriteLine("Enter test message file path ");
                    var testMsgPath = Console.ReadLine();
                    var msgFile = File.OpenRead(testMsgPath);
                    Message msg = System.ServiceModel.Channels.Message.CreateMessage(MessageVersion.Soap11, "BizTalkSubmit1", XmlTextReader.Create(msgFile));

                    string uriLocationEsbOnRamp = ConfigurationManager.AppSettings["GenericWebServiceUri"];

                    BasicHttpBinding b = new BasicHttpBinding();
                    //b.Security.Mode = BasicHttpSecurityMode.None;
                    EndpointAddress epa = new EndpointAddress(uriLocationEsbOnRamp);
                    IBizTalkSubmission proxy = ChannelFactory<IBizTalkSubmission>.CreateChannel(b, epa);

                    proxy.Submit(msg);
                    Console.WriteLine("Success");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception sending message");
                    Console.WriteLine(ex.Message);
                }
                Console.WriteLine();
                Console.Write("Type a 'X' key to exit, or any other key to test another message.");
                ConsoleKeyInfo key = Console.ReadKey();
                if (key.KeyChar == 'x' || key.KeyChar == 'X')
                {
                    exitLoop = true;
                }
                Console.WriteLine();
            }
        }
    }
}


