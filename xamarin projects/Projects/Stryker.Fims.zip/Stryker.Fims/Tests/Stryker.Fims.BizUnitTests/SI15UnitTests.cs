﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BizUnit;
using BizUnit.TestSteps.Common;
using BizUnit.TestSteps.File;
using BizUnit.TestSteps.ValidationSteps.Xml;
using BizUnit.Xaml;
using BizUnit.TestSteps.DataLoaders.File;
using System.Configuration;
using System.IO;
using Neudesic.BizTalk.Common.Testing;
using System.Text.RegularExpressions;
using System.Threading;

namespace Stryker.Fims.BizUnitTests
{
    [TestClass]
    public class SI15UnitTests
    {
        [TestMethod]
        public void SI15UnitTest()
        {
            try
            {
                Thread.Sleep(1000);
                string SI15BTSReceiveFolder = ConfigurationManager.AppSettings["SI15BTSReceiveFolder"];
                string SI15BTSOutputFolder = ConfigurationManager.AppSettings["SI15BTSOutputFolder"];

                var testCase = new TestCase()
                {
                    Name = "SI15 FIMS Purchase Order Canonical"
                };

                // Clean up from previous runs
                var fileDeleteStep = new DeleteStep()
                {
                    FilePathsToDelete = new System.Collections.ObjectModel.Collection<string>() {
                    SI15BTSOutputFolder + @"\*.xml"
                }
                };

                testCase.SetupSteps.Add(fileDeleteStep);

                // Create file step
                var createFileStep = new CreateStep()
                {
                    CreationPath = SI15BTSReceiveFolder + @"\QualityNotificationCanonical.xml"
                };

                var fileLoader = new FileDataLoader()
                {
                    FilePath = @".\QualityNotificationCanonical.xml"
                };

                createFileStep.DataSource = fileLoader;

                testCase.ExecutionSteps.Add(createFileStep);

                // Create a validating read step
                var validatingReadStep = new FileReadMultipleStep()
                {
                    DirectoryPath = SI15BTSOutputFolder,
                    SearchPattern = "*.xml",
                    ExpectedNumberOfFiles = 1,
                    Timeout = 6000
                };

                testCase.ExecutionSteps.Add(validatingReadStep);
                var bizUnit = new BizUnit.BizUnit(testCase);
                bizUnit.RunTest();

                var fileList = Directory.EnumerateFiles(SI15BTSOutputFolder, "*.xml");

                FileStream actualStream = File.Open(fileList.First(), FileMode.Open, FileAccess.Read, FileShare.Delete);
                StreamReader actualReader = new StreamReader(actualStream);
                string actual = actualReader.ReadToEnd().Trim();
                actual = Regex.Replace(actual, @"\s", "");

                FileStream expectedStream = File.Open(@".\ExpectedMessages\FIMS QualityNotificationMsg.xml", FileMode.Open, FileAccess.Read, FileShare.Delete);
                StreamReader expectedReader = new StreamReader(expectedStream);
                string expected = expectedReader.ReadToEnd().Trim();
                expected = Regex.Replace(expected, @"\s", "");

                actualStream.Close();
                expectedStream.Close();

                Assert.AreEqual(0, String.Compare(actual, expected), "SI-15 messages are different.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message.ToString());
                Assert.Fail(ex.Message.ToString());
            }
        }
    }
}
