﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BizUnit;
using BizUnit.TestSteps.Common;
using BizUnit.TestSteps.File;
using BizUnit.TestSteps.ValidationSteps.Xml;
using BizUnit.Xaml;
using BizUnit.TestSteps.DataLoaders.File;
using System.Configuration;
using System.IO;
using Neudesic.BizTalk.Common.Testing;
using System.Text.RegularExpressions;
using System.Threading;

namespace Stryker.Fims.BizUnitTests
{
    [TestClass]
    public class SI13UnitTests
    {

        [TestMethod]
        public void SI3UnitTest()
        {
            try
            {
                string si13ReadPath = ConfigurationManager.AppSettings["SI13ReadFolder"];
                string si13WritePath = ConfigurationManager.AppSettings["SI13WriteFolder"];

                var testCase = new TestCase()
                {
                    Name = "SI13 FIMS Limited Release Canonical Test"
                };
                // Clean up from previous runs
                var fileDeleteStep = new DeleteStep()
                {
                    FilePathsToDelete = new System.Collections.ObjectModel.Collection<string>() {
                    si13WritePath + @"\*.xml"
                }
                };
                testCase.SetupSteps.Add(fileDeleteStep);

                // Create file step
                var createFileStep = new CreateStep()
                {
                    CreationPath = si13ReadPath + @"\LimitedReleaseCanonical.xml"
                };

                var fileLoader = new FileDataLoader()
                {
                    FilePath = @".\LimitedReleaseCanonical.xml"
                };

                createFileStep.DataSource = fileLoader;

                testCase.ExecutionSteps.Add(createFileStep);

                // Create a validating read step
                var validatingReadStep = new FileReadMultipleStep()
                {
                    DirectoryPath = si13WritePath,
                    SearchPattern = "*.xml",
                    ExpectedNumberOfFiles = 1,
                    Timeout = 6000
                };


                var bizUnit = new BizUnit.BizUnit(testCase);
                bizUnit.RunTest();

                // wait for file to show up
                Thread.Sleep(5000);
                var fileList = Directory.EnumerateFiles(si13WritePath, "*.xml");
                FileStream actualStream = File.Open(fileList.First(), FileMode.Open, FileAccess.Read, FileShare.Delete);
                StreamReader actualReader = new StreamReader(actualStream);
                string actual = actualReader.ReadToEnd().Trim();
                actual = Regex.Replace(actual, @"\s", "");

                FileStream expectedStream = File.Open(@".\ExpectedMessages\FIMS LimitedReleaseMsg.xml", FileMode.Open, FileAccess.Read, FileShare.Delete);
                StreamReader expectedReader = new StreamReader(expectedStream);
                string expected = expectedReader.ReadToEnd().Trim();
                expected = Regex.Replace(expected, @"\s", "");

                actualStream.Close();
                expectedStream.Close();

                Assert.AreEqual(0, String.Compare(actual, expected), "SI-12 messages are different.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message.ToString());
                Assert.Fail(ex.Message.ToString());
            }
        }
    }
}
