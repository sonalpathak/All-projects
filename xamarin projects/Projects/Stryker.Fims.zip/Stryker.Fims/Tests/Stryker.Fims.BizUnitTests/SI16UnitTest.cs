﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BizUnit;
using BizUnit.TestSteps.Common;
using BizUnit.TestSteps.File;
using BizUnit.TestSteps.ValidationSteps.Xml;
using BizUnit.Xaml;
using BizUnit.TestSteps.DataLoaders.File;
using System.Configuration;
using System.IO;
using Neudesic.BizTalk.Common.Testing;
using System.Text.RegularExpressions;
using System.Threading;

namespace Stryker.Fims.BizUnitTests
{
    [TestClass]
    public class SI16UnitTests
    {
        [TestMethod]
        public void SI16UnitTest()
        {
            try
            {
                // check for invalid customer canonical message e.g. invalid Ship_To
                Thread.Sleep(1000);
                string SI16ReadPath = ConfigurationManager.AppSettings["SI16ReadFolder"];
                string SI16WritePath = ConfigurationManager.AppSettings["SI16WriteFolder"];

                var testCase = new TestCase()
                {
                    Name = "SI16 FIMS Customer Canonical with invalid SHIP_TO"
                };


                // Create file step
                var createFileStep = new CreateStep()
                {
                    CreationPath = SI16ReadPath + @"\CustomerCanonicalWrongShipTo.xml"
                };

                var fileLoader = new FileDataLoader()
                {
                    FilePath = @".\CustomerCanonicalWrongShipTo.xml"
                };

                createFileStep.DataSource = fileLoader;

                testCase.ExecutionSteps.Add(createFileStep);

                var bizUnit = new BizUnit.BizUnit(testCase);
                bizUnit.RunTest();

                // wait for file to show up
                Thread.Sleep(5000);
                var fileList = Directory.EnumerateFiles(SI16WritePath, "*.xml");

                FileStream actualStream = File.Open(fileList.First(), FileMode.Open, FileAccess.Read, FileShare.Delete);
                Assert.IsNotNull(actualStream);
                
            }
            catch
            {
                // file should not exists
                Assert.IsTrue(true);
            }
        }
    }
}
