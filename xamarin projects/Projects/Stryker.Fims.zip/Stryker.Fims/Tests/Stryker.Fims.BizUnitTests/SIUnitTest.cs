﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Nv.Mes.BizUnitTests
{
    [TestClass]
    public class SIUnitTest
    {
        [AssemblyInitialize()]
        public static void AssemblyInit(TestContext context)
        {
            System.Environment.CurrentDirectory = @"C:\StrykerMiddleware\Solutions\Stryker.Fims\Tests\TestMessages\";
        }
        public void TestMethod1()
        {
        }
    }
}
