﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BizUnit;
using BizUnit.TestSteps.Common;
using BizUnit.TestSteps.File;
using BizUnit.TestSteps.ValidationSteps.Xml;
using BizUnit.Xaml;
using BizUnit.TestSteps.DataLoaders.File;
using System.Configuration;
using Neudesic.BizTalk.Common.Testing;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;

namespace Stryker.Fims.BizUnitTests
{
    /// <summary>
    /// Summary description for SI11UnitTests
    /// </summary>
    [TestClass]
    public class SI11UnitTests
    {
        public SI11UnitTests()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void SI11UnitTest()
        {
            try
            {
                Thread.Sleep(1000);
                string si11ReadPath = ConfigurationManager.AppSettings["SI11ReadFolder"];
                string si11WritePath = ConfigurationManager.AppSettings["SI11WriteFolder"];

                var testCase = new TestCase()
                {
                    Name = "SI11 FIMS Inventory Canonical Test"
                };
                // Clean up from previous runs
                var fileDeleteStep = new DeleteStep()
                {
                    FilePathsToDelete = new System.Collections.ObjectModel.Collection<string>() {
                    si11WritePath + @"\*.xml"
                }
                };
                testCase.SetupSteps.Add(fileDeleteStep);

                // Create file step
                var createFileStep = new CreateStep()
                {
                    CreationPath = si11ReadPath + @"\InventoryCanonical.xml"
                };

                var fileLoader = new FileDataLoader()
                {
                    FilePath = @".\InventoryCanonical.xml"
                };

                createFileStep.DataSource = fileLoader;

                testCase.ExecutionSteps.Add(createFileStep);

                // Create a validating read step
                var validatingReadStep = new FileReadMultipleStep()
                {
                    DirectoryPath = si11WritePath,
                    SearchPattern = "*.xml",
                    ExpectedNumberOfFiles = 1,
                    Timeout = 6000
                };


                var bizUnit = new BizUnit.BizUnit(testCase);
                bizUnit.RunTest();

                // wait for file to show up
                Thread.Sleep(5000);
                var fileList = Directory.EnumerateFiles(si11WritePath, "*.xml");


                FileStream actualStream = File.Open(fileList.First(), FileMode.Open, FileAccess.Read, FileShare.Delete);
                StreamReader actualReader = new StreamReader(actualStream);
                string actual = actualReader.ReadToEnd().Trim();
                actual = Regex.Replace(actual, @"\s", "");

                FileStream expectedStream = File.Open(@".\ExpectedMessages\FIMS InventoryMsg.xml", FileMode.Open, FileAccess.Read, FileShare.Delete);
                StreamReader expectedReader = new StreamReader(expectedStream);
                string expected = expectedReader.ReadToEnd().Trim();
                expected = Regex.Replace(expected, @"\s", "");

                actualStream.Close();
                expectedStream.Close();

                Assert.AreEqual(0, String.Compare(actual, expected), "SI-11 messages are different.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message.ToString());
                Assert.Fail(ex.Message.ToString());
            }
        }
    }
}
