using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Media;



using Android.Locations;
using Android.Util;




namespace App
{
	[Activity (Label = "alarm")]			
	public class alarm : Activity
	{
		protected MediaPlayer _player;
		protected override void OnCreate (Bundle bundle)
		{
			_player = MediaPlayer.Create (this,Resource.Raw.police_alarm);
			base.OnCreate (bundle);
			SetContentView (Resource.Layout.alarm);
			FindViewById<TextView> (Resource.Id.Start_ALarm).Click+=Start_alarm_click;
			FindViewById<TextView> (Resource.Id.Stop_ALarm).Click += Stop_alarm_click;

			// Create your application here
		}
		public void Start_alarm_click(object sender, EventArgs eventArgs)
		{
			_player.Start ();

		} 
		public void Stop_alarm_click(object sender, EventArgs eventArgs)
		{
			_player.Stop ();
		}

	}
}

