﻿using Cirrious.MvvmCross.ViewModels;

namespace CoolBeans.ViewModels
{
    public class AboutViewModel 
        : MvxViewModel
    {
    }
}
