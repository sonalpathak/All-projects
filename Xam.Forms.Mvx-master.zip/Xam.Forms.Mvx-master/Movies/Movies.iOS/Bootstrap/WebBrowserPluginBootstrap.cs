using Cirrious.CrossCore.Plugins;

namespace CoolBeans.iOS.Bootstrap
{
    public class WebBrowserPluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.WebBrowser.PluginLoader, Cirrious.MvvmCross.Plugins.WebBrowser.Touch.Plugin>
    {
    }
}