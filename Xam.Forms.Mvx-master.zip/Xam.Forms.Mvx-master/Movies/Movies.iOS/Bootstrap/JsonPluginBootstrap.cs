using Cirrious.CrossCore.Plugins;

namespace CoolBeans.iOS.Bootstrap
{
    public class JsonPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.Json.PluginLoader>
    {
    }
}