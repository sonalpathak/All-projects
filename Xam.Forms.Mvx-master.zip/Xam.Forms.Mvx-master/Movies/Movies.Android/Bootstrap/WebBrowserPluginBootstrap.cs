using Cirrious.CrossCore.Plugins;

namespace CoolBeans.Droid.Bootstrap
{
    public class WebBrowserPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.WebBrowser.PluginLoader>
    {
    }
}