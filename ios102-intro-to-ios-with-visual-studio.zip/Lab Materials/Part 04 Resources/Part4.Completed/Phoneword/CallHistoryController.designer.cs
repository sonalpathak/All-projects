// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using System;
using Foundation;
using UIKit;
using System.CodeDom.Compiler;

namespace Phoneword
{
	[Register ("CallHistoryController")]
	partial class CallHistoryController
	{
		void ReleaseDesignerOutlets ()
		{
		}
	}
}
