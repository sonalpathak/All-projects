﻿using Xamarin.Forms;

namespace MasterDetailPageNavigation
{
	public partial class ContactsPage : ContentPage
	{
		public ContactsPage ()
		{
			InitializeComponent ();
		}
	}
}

